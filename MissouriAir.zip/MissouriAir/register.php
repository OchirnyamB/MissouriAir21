<?php require("includes/header.php"); ?>

<?php
include 'web_logging.php';
define("HOST", "LOCALHOST");
define("USERNAME", "CS3380GRP21");
define("PASSWORD", "5d91bc2");
define("DBNAME", "CS3380GRP21");
?>

  <div class="top-content">
    <div class="inner-bg">
      <div class="container">
        <div class="row">
          <div class="col-sm-8 col-sm-offset-2 text">
            <h1><strong>Register</strong> Account</h1>
            <div class="description">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-6 col-sm-offset-3 form-box">
            <div class="form-top">
              <div class="form-top-left">
                <h3> Please enter you account information: </h3>
              </div>
              <div class="form-top-right">
                <i class="fa fa-user-plus"></i>
              </div>
            </div>
            <div class="form-bottom">
              <form role="form" action="register.php" method="post" class="login-form">
                <div class="form-group">
                  <label>First Name:</label>
                  <input type="text" name="cus_fname" class="form-username form-control" id="form-username">
                </div>
                <div class="form-group">
                  <label>Last Name:</label>
                  <input type="text" name="cus_lname" class="form-username form-control" id="form-username">
                </div>
                <div class="form-group">
                  <label>Age:</label>
                  <select name="cus_age" class="form-username form-control">
                    <?php for ($i = 1; $i <= 120; $i++) : ?>
                      <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                    <?php endfor; ?>
                  </select>
                </div>
                <div class="form-group">
                  <label>Username:</label>
                  <input type="text" name="cus_user" class="form-username form-control" id="form-username">
                </div>
                <div class="form-group">
                  <label>Password:</label>
                  <input type="password" name="password" class="form-password form-control" id="form-password">
                </div>
                <div class="form-group">
                  <label>Confirm Password:</label>
                  <input type="password" name="password2" class="form-password form-control" id="form-password">
                </div>
                <button type="submit" name="register" class="btn btn-success"> Create your account </button>
              </form>
              <?php
              $link = mysqli_connect(HOST, USERNAME, PASSWORD, DBNAME) or die ("113" . mysqli_connect_error);

              if(isset($_POST['register'])) {
                // Check if andy of the fields are empty
                if(empty($_POST['cus_fname']) || empty($_POST['cus_lname']) || empty($_POST['cus_age']) || empty($_POST['cus_user']) || empty($_POST['password']) || empty($_POST['password2'])) {
                  echo "<h2>Please fill out all fields.</h2>";
                }
                else if(strcmp($_POST['password'], $_POST['password2']) != 0) {
                  echo "<h2>Passwords do not match.</h2>";
                }
                else if(strlen($_POST['cus_user']) > 32 || strlen($_POST['password']) > 32) {
                  echo "<h2>Usernames and passwords must be not more than 30 characters.</h2>";
                }
                else {
                  $role = 'customer';
                  // Create SQL statements for inserting user, employee, and authentication
                  $sql = "INSERT INTO user (fname, lname, role) VALUES (?, ?, ?)";
                  if($stmt = mysqli_prepare($link, $sql)) {
                    mysqli_stmt_bind_param($stmt, 'sss', $_POST['cus_fname'], $_POST['cus_lname'], $role);
                    if(mysqli_stmt_execute($stmt)) {
                      // Create query to get the highest user_id so we can insert into customer
                      // and authentication appropriately.
                      $query = "SELECT user_id FROM user ORDER BY user_id DESC";
                      $result = mysqli_query($link, $query);
                      if($result) {
                        $row = mysqli_fetch_array($result, MYSQLI_NUM);
                        $current_id = $row[0];
                      }
                      // Now that user has been inserted time to insert into employee
                      $sql = "INSERT INTO customer (customer_id, age) VALUES (?, ?)";
                      if($stmt = mysqli_prepare($link, $sql)) {
                        mysqli_stmt_bind_param($stmt, 'ii', $current_id, $_POST['cus_age']);
                        if(mysqli_stmt_execute($stmt)) {
                          // Now we can finally insert into authentication
                          $sql = "INSERT INTO authentication (user_id, passname, password) VALUES (?, ?, ?)";
                          if($stmt = mysqli_prepare($link, $sql)) {
                            mysqli_stmt_bind_param($stmt, 'iss', $current_id, $_POST['cus_user'], md5($_POST['password']));
                            if(mysqli_stmt_execute($stmt)) {
                              echo "<h2>Your account successfully created. You can now log in.</h2>";
                              $action = "Created customer account";
                              create_log($link,$current_id,$action);
                              // Now create and insert a log saying an customer account was created
                            }
                            else {
                              echo "<h2>Username is already taked.</h2>";
                            }
                          }
                        }
                      }
                    }
                    else {
                      echo "<h2>Error creating customer account.</h2>";
                    }
                  }
                  else {
                    echo "<h2>Error preparing statement.</h2>";
                  }
                }
              }
              ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php require("includes/footer.php"); ?>
