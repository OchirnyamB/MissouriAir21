<?php
session_start();
if(isset($_SESSION['role'])) {
    if(strcmp($_SESSION['role'], 'admin') == 0) {
      header("location: administrator.php");
    }
    if(strcmp($_SESSION['role'], 'attendant') == 0) {
      header("location: attendant.php");
    }
    if(strcmp($_SESSION['role'], 'pilot') == 0) {
      header("location: pilot.php");
    }
    if(strcmp($_SESSION['role'], 'customer') == 0) {
      header("location: customer.php");
    }
  }
  else {
    header("location: login.php");
  }
?>
