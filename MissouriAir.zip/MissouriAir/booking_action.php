<?php
session_start();
require("includes/header.php");
include 'web_logging.php';
?>
<div>
<br><br><br>
        <div class="well">
		<?php 
		  if(isset($_POST['book'])){
				  $hostname = 'localhost';
				  $username = 'CS3380GRP21';
				  $password = '5d91bc2';
				  $database = 'CS3380GRP21';
				  $conn = mysqli_connect($hostname, $username, $password, $database);
				  if (!$conn){
					  die("Failed to connect to MySQL:" .mysqli_connect_error());
				  }else{
					   $flight_id = $_SESSION['flight_key'];
					   if(!isset($_SESSION['user_id'])){
						  echo '<script type="text/javascript">
						   window.location = "login.php"
						  </script>';
					   }else{
						   $customer_id = $_SESSION['user_id'];
						   $date = $_SESSION['date'];
						   $price = $_SESSION['price'];
						   $number_bags = $_POST['number_bags'];  
						   if($customer_id){
							   $sql = "INSERT INTO reservation (flight_id, customer_id, date_reserved, num_bags) VALUES(?,?,?,?)";
							   if($stmt = mysqli_prepare($conn, $sql)){
								   if(mysqli_stmt_bind_param($stmt, 'ssss',$flight_id, $customer_id, $date, $number_bags)){
									   if(mysqli_stmt_execute($stmt)){
										   echo "<h3 style='color:#888'>Reservation has been successfull!</h3>";
										   create_log($conn, $_SESSION['user_id'], "Customer reserved flight");
									   }else{
										   echo "<h3 style='color:#888'>Reservation failed! </h3>";
									   }
								   }
								   else{
									   echo "Bind has failed!";   
								   }
							   }
						   }else{
							   echo '<script type="text/javascript">
									   window.location = "login.php"
									  </script>';
						   } 
						   echo "<b>FlightId: </b>".$flight_id."<br>";
						   echo "<b>Date: </b>".$date."<br>";
						   echo "<b>Customer_id </b>: ".$customer_id."<br>";
						   echo "<b>Number of bags </b>: ".$number_bags."<br>";
						   $total_price = $price + ($number_bags*20);
						   $total_price = $total_price + $total_price/100*5;
						   echo "<b>Total price after 5% sales tax: $</b>".$total_price."<br>";
						
					   }
				  }

			  }
		  
	    ?>
        </div>
</div>
<?php
require("includes/footer.php");
?>
