<?php require("includes/header.php"); ?>

<?php
include 'web_logging.php';
define("HOST", "LOCALHOST");
define("USERNAME", "CS3380GRP21");
define("PASSWORD", "5d91bc2");
define("DBNAME", "CS3380GRP21");

if(isset($_SESSION['user_id'])){
	session_unset();
	session_destroy();
}

?>

  <div class="top-content">
    <div class="inner-bg">
      <div class="container">
        <div class="row">
          <div class="col-sm-8 col-sm-offset-2 text">
            <h1><strong>User</strong> Login</h1>
            <div class="description">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-6 col-sm-offset-3 form-box">
            <div class="form-top">
              <div class="form-top-left">
                <h3> Please enter your username and password </h3>
              </div>
              <div class="form-top-right">
                <i class="fa fa-user"></i>
              </div>
            </div>
            <div class="form-bottom">
              <form role="form" action="login.php" method="post" class="login-form">
                <div class="form-group">
                  <label class="sr-only" for="username">Username</label>
                  <input type="text" name="username" placeholder="Username" class="form-username form-control" id="form-username">
                </div>
                <div class="form-group">
                  <label class="sr-only" for="password">Password</label>
                  <input type="password" name="password" placeholder="Password" class="form-password form-control" id="form-password">
                </div>
                <button type="submit" name="login" class="btn btn-success">Login!</button>
				<?php
				$link = mysqli_connect(HOST, USERNAME, PASSWORD, DBNAME) or die ("103" . mysqli_connect_error);

				if(isset($_POST['login'])) {
				  $myusername = $_POST['username'];
				  $mypassword = md5($_POST['password']);
				  $sql = "SELECT passname, password, role, user.user_id FROM authentication JOIN user ON authentication.user_id = user.user_id
						  WHERE passname = '$myusername' AND password = '$mypassword'";
				  // Check for empty fields
				  if (empty($_POST['username']) || empty($_POST['password'])) {
					echo "Please enter valid information.";
				  }
				  else {
					$result = mysqli_query($link,$sql);
					$count = mysqli_num_rows($result);
					if($count == 1) {
					  $row = mysqli_fetch_array($result, MYSQLI_NUM);
					  session_start();
					  $_SESSION['username'] = $myusername;
					  $_SESSION['role'] = $row[2];
					  $_SESSION['user_id'] = $row[3];

					  $action = "Logged into account.";
					  create_log($link,$_SESSION['user_id'],$action);

					  // User is a customer
					  if(strcmp($_SESSION['role'], 'customer') == 0) {
						header("location: customer.php");
					  }
					  // User is an administrator
					  else if(strcmp($_SESSION['role'], 'admin') == 0) {
						header("location: administrator.php");
					  }
					  // User is a pilot
					  else if(strcmp($_SESSION['role'], 'pilot') == 0) {
						header("location: pilot.php");
					  }
					  // User is an attendant
					  else if(strcmp($_SESSION['role'], 'attendant') == 0) {
						header("location: attendant.php");
					  }
					}
					// Either username or password were incorret
					else {
					  echo "<h3 style='color:#de615e'>Username or password incorrect!</h3>";
					}
				  }
				}
				?>
              </form>
              <label> Don't have an account? <a href="register.php"> Click here to register </a></label>
              <!--<form role="form" action="register.php" method="post" class="register-form">
              <button type="submit" name="register" class="btn btn-info">Register!</button>
            </form> -->

          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require("includes/footer.php"); ?>
