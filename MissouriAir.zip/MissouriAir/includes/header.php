<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Missouri Airlines</title>
  
  <!-- CSS -->
	<link href="https://fonts.googleapis.com/css?family=Hind:300,400,500,600,700|Ubuntu:300,400,500,500i,700" rel="stylesheet">
	<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">
	<link rel="stylesheet" href="assets/font-awesome/css/font-awesome.css">
	<link rel="stylesheet" href="assets/css/form-elements.css">
	<link rel="stylesheet" href="assets/css/style.css">

  <!-- Favicons -->
	<link rel="apple-touch-icon" sizes="180x180" href="favicons/apple-touch-icon.png">
	<link rel="icon" type="image/png" href="favicons/favicon-32x32.png" sizes="32x32">
	<link rel="icon" type="image/png" href="favicons/favicon-16x16.png" sizes="16x16">
	<link rel="manifest" href="favicons/manifest.json">
	<link rel="mask-icon" href="favicons/safari-pinned-tab.svg" color="#5bbad5">
	<meta name="theme-color" content="#ffffff">
</head>

<body>

  <!-- navbar begin -->
  <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#">Missouri Airlines</a>
      </div>
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav">
          <li><a href="index.php">Home</a></li>
          <li><a href="search_flights.php">Search Flights</a></li>
          <li><a href="reservations.php">View Reservations</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          
        <?php
              if(isset($_SESSION['user_id'])) {
              echo "<li><a href='account.php'>Account</a></li>";
              echo "<li><a href='logout.php'>Logout</a></li>";
            } else {
              echo "<li><a href='register.php'>Register</a></li>";
              echo "<li><a href='login.php'>Login</a></li>";
            }
        ?>
        </ul>
      </div><!--/.nav-collapse -->
    </div>
  </nav>
  <!-- navbar end -->