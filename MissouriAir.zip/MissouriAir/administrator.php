<?php
session_start();
include 'web_logging.php';
define("HOST", "LOCALHOST");
define("USERNAME", "CS3380GRP21");
define("PASSWORD", "5d91bc2");
define("DBNAME", "CS3380GRP21");

if(strcmp($_SESSION['role'], 'admin') != 0) {
  header("location: access_denied.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Administrator</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Hind:300,400,500,600,700|Ubuntu:300,400,500,500i,700" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  /* Set black background color, white text and some padding */
  body {

  }

  .well {

  }

  h3 {
    margin-top: 0;
  }

  #left-well {
    max-width: 200px;
  }

  .btn {
    width: 160px;
  }

  .btn-danger, .btn-warning {
    width: 80px;
  }

  .btn-default {
    border: none;
  }

  .content {
    margin-left: 5%;
    margin-right: 5%;
  }
  </style>
</head>
<body>

  <!-- navbar begin -->
  <nav class="navbar navbar-inverse navbar-fixed-top" style='font-family='Ubuntu',sans-serif;font-weight=900;'>
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#">Missouri Airlines</a>
      </div>
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav">
          <li><a href="index.php">Home</a></li>
          <li><a href="search_flights.php">Search Flights</a></li>
          <li><a href="reservations.php">View Reservations</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <?php
            if(isset($_SESSION['user_id'])) {
              echo "<li><a href='account.php'>Account</a></li>";
              echo "<li><a href='logout.php'>Logout</a></li>";
            } else {
              echo "<li><a href='register.php'>Register</a></li>";
              echo "<li><a href='login.php'>Login</a></li>";
            }
          ?>
        </ul>
      </div><!--/.nav-collapse -->
    </div>
  </nav>
  <!-- navbar end -->

  <!-- Not great practice but static navbar is weird -->
  <br>
  <br>
  <br>

  <div class='content'>
    <h1> Welcome Administrator </h1>
    <h2> Employee Number: <?php echo $_SESSION['user_id'] ?> </h2>
    <div class="row">
      <div class="col-md-3">
        <div class="well" id="left-well">
          <h3>Actions:</h3>
          <form role="form" action="administrator.php" method="POST">
            <button name="overview" value="overview" class="btn btn-success">Overview </button><br><br>
            <div class="dropdown">
              <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown">Add User
                <span class="caret"></span></button>
                <ul class="dropdown-menu">
                  <li><button name="add_admin" value="add_admin" class="btn btn-default">Add Admin </button></li>
                  <li><button name="add_att" value="add_att" class="btn btn-default">Add Attendant </button></li>
                  <li><button name="add_customer" value="add_customer" class="btn btn-default">Add Customer </button></li>
                  <li><button name="add_pilot" value="add_pilot" class="btn btn-default">Add Pilot </button></li>
                </ul>
              </div><br>
              <div class="dropdown">
                <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown">Update User
                  <span class="caret"></span></button>
                  <ul class="dropdown-menu">
                    <li><button name="update_admin" value="update_admin" class="btn btn-default">Update Admin </button></li>
                    <li><button name="update_att" value="update_att" class="btn btn-default">Update Attendant </button></li>
                    <li><button name="update_customer" value="update_customer" class="btn btn-default">Update Customer </button></li>
                    <li><button name="update_pilot" value="update_pilot" class="btn btn-default">Update Pilot </button></li>
                  </ul>
                </div><br>
                <div class="dropdown">
                  <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown">Manage Flights
                    <span class="caret"></span></button>
                    <ul class="dropdown-menu">
                      <li><button name="add_flight" value="add_flight" class="btn btn-default">Add Flight </button></li>
                      <li><button name="update_flight" value="update_flight" class="btn btn-default">Update Flight </button></li>
                      <li><button name="add_pilot_flight" value="add_pilot_flight" class="btn btn-default">Add Pilot to Flight </button></li>
                      <li><button name="add_att_flight" value="add_att_flight" class="btn btn-default">Add Attendant to Flight </button></li>
                    </ul>
                  </div><br>
                  <div class="dropdown">
                    <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown">Manage Equipment
                      <span class="caret"></span></button>
                      <ul class="dropdown-menu">
                        <li><button name="add_equipment" value="add_equipment" class="btn btn-default">Add equipment </button></li>
                        <li><button name="update_equipment" value="update_equipment" class="btn btn-default">Remove Equipment </button></li>
                      </ul>
                    </div><br>
                    <button name="view_logs" value="view_logs" class="btn btn-success">View Logs </button><br>
                  </form>
                </div>
              </div>
              <div class="col-md-9">
                <?php
                $link = mysqli_connect(HOST, USERNAME, PASSWORD, DBNAME) or die ("103" . mysqli_connect_error);
                $id = $_SESSION['user_id'];

                $query = "SELECT fname, lname FROM admin JOIN user
                ON admin.admin_id = user.user_id WHERE user.user_id = '$id'";

                $result = mysqli_query($link, $query);
                if($result) {
                  $row = mysqli_fetch_array($result, MYSQLI_NUM);
                  ob_start();
                  echo "<div class='well'>";
                  echo "<h1>Administrator Information:</h1>";
                  echo "<h2>First Name: " . $row[0] . "</h2>";
                  echo "<h2>Last Name: " . $row[1] . "</h2>";
                  echo "</div>";
                }
                if(isset($_POST['overview'])) {
                  ob_end_clean();
                  ob_start();

                  $query = "SELECT fname, lname FROM admin JOIN user
                  ON admin.admin_id = user.user_id WHERE user.user_id = '$id'";

                  $result = mysqli_query($link,$query);
                  if($result) {
                    $row = mysqli_fetch_array($result, MYSQLI_NUM);
                    ob_start();
                    echo "<div class='well'>";
                    echo "<h1>Administrator Information:</h1>";
                    echo "<h2>First Name: " . $row[0] . "</h2>";
                    echo "<h2>Last Name: " . $row[1] . "</h2>";
                    echo "</div>";
                  }
                }

                //
                // Add admin
                //
                if(isset($_POST['add_admin'])) {
                  // Reset the output buffer
                  ob_end_clean();
                  ob_start();
                  // Print all of the input forms for admin account
                  echo "<div class='well'>";
                  echo "<h1>Add Administrator:</h1>";
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  echo "<br><label>First Name:</label><br>";
                  echo "<input type='text' name='admin_fname' class='form-control'><br><br>";
                  echo "<label>Last Name:</label><br>";
                  echo "<input type='text' name='admin_lname' class='form-control'><br><br>";
                  echo "<label>Userame:</label><br>";
                  echo "<input type='text' name='admin_user' class='form-control'><br><br>";
                  echo "<label>Password:</label><br>";
                  echo "<input type='text' name='admin_pass' class='form-control'><br><br>";
                  echo "<button type='submit' name='insert_admin' value='insert_admin' class='btn btn-primary'>Create Admin</button>";
                  echo "</form>";
                  echo "</div>";
                }
                if(isset($_POST['insert_admin'])) {
                  // Check if andy of the fields are empty
                  if(empty($_POST['admin_fname']) || empty($_POST['admin_lname']) || empty($_POST['admin_user']) || empty($_POST['admin_pass'])) {
                    echo "<h2>Please fill out all fields.</h2>";
                  }
                  else if(strlen($_POST['admin_user']) > 30 || strlen($_POST['admin_pass']) > 30) {
                    echo "<h2>Usernames and passwords must be not more than 30 characters.</h2>";
                  }
                  else {
                    $role = 'admin';
                    // Create SQL statements for inserting user, employee, and authentication
                    $sql = "INSERT INTO user (fname, lname, role) VALUES (?, ?, ?)";
                    if($stmt = mysqli_prepare($link, $sql)) {
                      mysqli_stmt_bind_param($stmt, 'sss', $_POST['admin_fname'], $_POST['admin_lname'], $role);
                      if(mysqli_stmt_execute($stmt)) {
                        // Create query to get the highest user_id so we can insert into employee
                        // and authentication appropriately.
                        $query = "SELECT user_id FROM user ORDER BY user_id DESC";
                        $result = mysqli_query($link, $query);
                        if($result) {
                          $row = mysqli_fetch_array($result, MYSQLI_NUM);
                          $current_id = $row[0];
                        }
                        // Now that user has been inserted time to insert into employee
                        $sql = "INSERT INTO employee (employee_id) VALUES (?)";
                        if($stmt = mysqli_prepare($link, $sql)) {
                          mysqli_stmt_bind_param($stmt, 'i', $current_id);
                          if(mysqli_stmt_execute($stmt)) {
                            // Now we should insert into the admin table
                            $sql = "INSERT INTO admin (admin_id) VALUES (?)";
                            if($stmt = mysqli_prepare($link, $sql)) {
                              mysqli_stmt_bind_param($stmt, 'i', $current_id);
                              if(mysqli_stmt_execute($stmt)) {
                                // Now we can finally insert into authentication
                                $sql = "INSERT INTO authentication (user_id, passname, password) VALUES (?, ?, ?)";
                                if($stmt = mysqli_prepare($link, $sql)) {
                                  mysqli_stmt_bind_param($stmt, 'iss', $current_id, $_POST['admin_user'], md5($_POST['admin_pass']));
                                  if(mysqli_stmt_execute($stmt)) {
                                    echo "<h2>Administrator account successfully created.</h2>";
                                    $action = "Created administrator acount";
                                    create_log($link,$_SESSION['user_id'],$action);
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                      else {
                        echo "<h2>Error creating administrator account.</h2>";
                      }
                    }
                    else {
                      echo "<h2>Error preparing statement.</h2>";
                    }
                  }
                }
                // SWEET JESUS THAT WAS AWFUL

                //
                // Add attendant
                //
                if(isset($_POST['add_att'])) {
                  ob_end_clean();
                  ob_start();
                  echo "<div class='well'>";
                  echo "<h1>Add Flight Attendant:</h1>";
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  echo "<br><label>First Name:</label><br>";
                  echo "<input type='text' name='att_fname' class='form-control'><br><br>";
                  echo "<label>Last Name:</label><br>";
                  echo "<input type='text' name='att_lname' class='form-control'><br><br>";
                  echo "<label>Attendant Rank:</label><br>";
                  echo "<select name='att_rank' class='form-control'>";
                  echo "<option value='junior'>Junior</option>";
                  echo "<option value='senior'>Senior</option>";
                  echo "</select><br><br>";
                  echo "<label>Attendant Status:</label><br>";
                  echo "<select name='att_status' class='form-control'>";
                  echo "<option value='active'>Active</option>";
                  echo "<option value='inactive'>Inactive</option>";
                  echo "</select><br><br>";
                  echo "<label>Userame:</label><br>";
                  echo "<input type='text' name='att_user' class='form-control'><br><br>";
                  echo "<label>Password:</label><br>";
                  echo "<input type='text' name='att_pass' class='form-control'><br><br>";
                  echo "<button type='submit' name='insert_att' value='insert_att' class='btn btn-primary'>Create Attendant</button>";
                  echo "</form>";
                  echo "</div>";
                }
                if(isset($_POST['insert_att'])) {
                  // Check if andy of the fields are empty
                  if(empty($_POST['att_fname']) || empty($_POST['att_lname']) || empty($_POST['att_user']) || empty($_POST['att_pass'])) {
                    echo "<h2>Please fill out all fields.</h2>";
                  }
                  else if(strlen($_POST['att_user']) > 30 || strlen($_POST['att_pass']) > 30) {
                    echo "<h2>Usernames and passwords must be not more than 30 characters.</h2>";
                  }
                  else {
                    $role = 'attendant';
                    // Create SQL statements for inserting user, employee, and authentication
                    $sql = "INSERT INTO user (fname, lname, role) VALUES (?, ?, ?)";
                    if($stmt = mysqli_prepare($link, $sql)) {
                      mysqli_stmt_bind_param($stmt, 'sss', $_POST['att_fname'], $_POST['att_lname'], $role);
                      if(mysqli_stmt_execute($stmt)) {
                        // Create query to get the highest user_id so we can insert into employee
                        // and authentication appropriately.
                        $query = "SELECT user_id FROM user ORDER BY user_id DESC";
                        $result = mysqli_query($link, $query);
                        if($result) {
                          $row = mysqli_fetch_array($result, MYSQLI_NUM);
                          $current_id = $row[0];
                        }
                        // Now that user has been inserted time to insert into employee
                        $sql = "INSERT INTO employee (employee_id) VALUES (?)";
                        if($stmt = mysqli_prepare($link, $sql)) {
                          mysqli_stmt_bind_param($stmt, 'i', $current_id);
                          if(mysqli_stmt_execute($stmt)) {
                            // Now we should insert into the attendant table
                            $sql = "INSERT INTO attendant (attendant_id, attendant_rank, attendant_status) VALUES (?, ?, ?)";
                            if($stmt = mysqli_prepare($link, $sql)) {
                              mysqli_stmt_bind_param($stmt, 'iss', $current_id, $_POST['att_rank'], $_POST['att_status']);
                              if(mysqli_stmt_execute($stmt)) {
                                // Now we can finally insert into authentication
                                $sql = "INSERT INTO authentication (user_id, passname, password) VALUES (?, ?, ?)";
                                if($stmt = mysqli_prepare($link, $sql)) {
                                  mysqli_stmt_bind_param($stmt, 'iss', $current_id, $_POST['att_user'], md5($_POST['att_pass']));
                                  if(mysqli_stmt_execute($stmt)) {
                                    echo "<h2>Attendant account successfully created.</h2>";
                                    $action = "Created attendant account";
                                    create_log($link,$_SESSION['user_id'],$action);
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                      else {
                        echo "<h2>Error creating attendant account.</h2>";
                      }
                    }
                    else {
                      echo "<h2>Error preparing statement.</h2>";
                    }
                  }
                }

                //
                // Add pilot
                //
                if(isset($_POST['add_pilot'])) {
                  ob_end_clean();
                  ob_start();
                  echo "<div class='well'>";
                  echo "<h1>Add Pilot:</h1>";
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  echo "<br><label>First Name:</label><br>";
                  echo "<input type='text' name='pilot_fname' class='form-control'><br><br>";
                  echo "<label>Last Name:</label><br>";
                  echo "<input type='text' name='pilot_lname' class='form-control'><br><br>";
                  echo "<label>Flight Hours:</label><br>";
                  echo "<input type='number' name='pilot_fhours' class='form-control'><br><br>";
                  echo "<label>Pilot Rank:</label><br>";
                  echo "<select name='pilot_rank' class='form-control'>";
                  echo "<option value='first officer'>First Officier</option>";
                  echo "<option value='captain'>Captain</option>";
                  echo "<option value='senior captain'>Senior Captain</option>";
                  echo "</select><br><br>";
                  echo "<br><label>Pilot Status:</label><br>";
                  echo "<select name='pilot_status' class='form-control'>";
                  echo "<option value='active'>Active</option>";
                  echo "<option value='inactive'>Inactive</option>";
                  echo "</select><br><br>";
                  echo "<label>Userame:</label><br>";
                  echo "<input type='text' name='pilot_user' class='form-control'><br><br>";
                  echo "<label>Password:</label><br>";
                  echo "<input type='text' name='pilot_pass' class='form-control'><br><br>";
                  echo "<button type='submit' name='insert_pilot' value='insert_pilot' class='btn btn-primary'>Create Pilot</button>";
                  echo "</form>";
                  echo "</div>";
                }
                if(isset($_POST['insert_pilot'])) {
                  // Check if andy of the fields are empty
                  if(empty($_POST['pilot_fname']) || empty($_POST['pilot_lname']) || empty($_POST['pilot_fhours']) || empty($_POST['pilot_user']) || empty($_POST['pilot_pass'])) {
                    echo "<h2>Please fill out all fields.</h2>";
                  }
                  else if(strlen($_POST['pilot_user']) > 30 || strlen($_POST['pilot_pass']) > 30) {
                    echo "<h2>Usernames and passwords must be not more than 30 characters.</h2>";
                  }
                  else {
                    $role = 'pilot';
                    // Create SQL statements for inserting user, employee, and authentication
                    $sql = "INSERT INTO user (fname, lname, role) VALUES (?, ?, ?)";
                    if($stmt = mysqli_prepare($link, $sql)) {
                      mysqli_stmt_bind_param($stmt, 'sss', $_POST['pilot_fname'], $_POST['pilot_lname'], $role);
                      if(mysqli_stmt_execute($stmt)) {
                        // Create query to get the highest user_id so we can insert into employee
                        // and authentication appropriately.
                        $query = "SELECT user_id FROM user ORDER BY user_id DESC";
                        $result = mysqli_query($link, $query);
                        if($result) {
                          $row = mysqli_fetch_array($result, MYSQLI_NUM);
                          $current_id = $row[0];
                        }
                        // Now that user has been inserted time to insert into employee
                        $sql = "INSERT INTO employee (employee_id) VALUES (?)";
                        if($stmt = mysqli_prepare($link, $sql)) {
                          mysqli_stmt_bind_param($stmt, 'i', $current_id);
                          if(mysqli_stmt_execute($stmt)) {
                            // Now we should insert into the pilot table
                            $sql = "INSERT INTO pilot (pilot_id, status, flight_hours, pilot_rank) VALUES (?, ?, ?, ?)";
                            if($stmt = mysqli_prepare($link, $sql)) {
                              mysqli_stmt_bind_param($stmt, 'isis', $current_id, $_POST['pilot_status'], $_POST['pilot_fhours'], $_POST['pilot_rank']);
                              if(mysqli_stmt_execute($stmt)) {
                                // Now we can finally insert into authentication
                                $sql = "INSERT INTO authentication (user_id, passname, password) VALUES (?, ?, ?)";
                                if($stmt = mysqli_prepare($link, $sql)) {
                                  mysqli_stmt_bind_param($stmt, 'iss', $current_id, $_POST['pilot_user'], md5($_POST['pilot_pass']));
                                  if(mysqli_stmt_execute($stmt)) {
                                    echo "<h2>Pilot account successfully created.</h2>";
                                    $action = "Created pilot account";
                                    create_log($link,$_SESSION['user_id'],$action);
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                      else {
                        echo "<h2>Error creating pilot account.</h2>";
                      }
                    }
                    else {
                      echo "<h2>Error preparing statement.</h2>";
                    }
                  }
                }

                //
                // Add customer
                //
                if(isset($_POST['add_customer'])) {
                  ob_end_clean();
                  ob_start();
                  echo "<div class='well'>";
                  echo "<h1>Add Customer:</h1>";
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  echo "<br><label>First Name:</label><br>";
                  echo "<input type='text' name='cus_fname' class='form-control'><br><br>";
                  echo "<label>Last Name:</label><br>";
                  echo "<input type='text' name='cus_lname' class='form-control'><br><br>";
                  echo "<label>Age:</label><br>";
                  echo "<input type='number' name='cus_age' class='form-control'><br><br>";
                  echo "<label>Userame:</label><br>";
                  echo "<input type='text' name='cus_user' class='form-control'><br><br>";
                  echo "<label>Password:</label><br>";
                  echo "<input type='text' name='cus_pass' class='form-control'><br><br>";
                  echo "<button type='submit' name='insert_customer' value='insert_customer' class='btn btn-primary'>Create Customer</button>";
                  echo "</form>";
                  echo "</div>";
                }
                if(isset($_POST['insert_customer'])) {
                  // Check if andy of the fields are empty
                  if(empty($_POST['cus_fname']) || empty($_POST['cus_lname']) || empty($_POST['cus_age']) || empty($_POST['cus_user']) || empty($_POST['cus_pass'])) {
                    echo "<h2>Please fill out all fields.</h2>";
                  }
                  else if(strlen($_POST['cus_user']) > 30 || strlen($_POST['cus_pass']) > 30) {
                    echo "<h2>Usernames and passwords must be not more than 30 characters.</h2>";
                  }
                  else {
                    $role = 'customer';
                    // Create SQL statements for inserting user, employee, and authentication
                    $sql = "INSERT INTO user (fname, lname, role) VALUES (?, ?, ?)";
                    if($stmt = mysqli_prepare($link, $sql)) {
                      mysqli_stmt_bind_param($stmt, 'sss', $_POST['cus_fname'], $_POST['cus_lname'], $role);
                      if(mysqli_stmt_execute($stmt)) {
                        // Create query to get the highest user_id so we can insert into customer
                        // and authentication appropriately.
                        $query = "SELECT user_id FROM user ORDER BY user_id DESC";
                        $result = mysqli_query($link, $query);
                        if($result) {
                          $row = mysqli_fetch_array($result, MYSQLI_NUM);
                          $current_id = $row[0];
                        }
                        // Now that user has been inserted time to insert into employee
                        $sql = "INSERT INTO customer (customer_id, age) VALUES (?, ?)";
                        if($stmt = mysqli_prepare($link, $sql)) {
                          mysqli_stmt_bind_param($stmt, 'ii', $current_id, $_POST['cus_age']);
                          if(mysqli_stmt_execute($stmt)) {
                            // Now we can finally insert into authentication
                            $sql = "INSERT INTO authentication (user_id, passname, password) VALUES (?, ?, ?)";
                            if($stmt = mysqli_prepare($link, $sql)) {
                              mysqli_stmt_bind_param($stmt, 'iss', $current_id, $_POST['cus_user'], md5($_POST['cus_pass']));
                              if(mysqli_stmt_execute($stmt)) {
                                echo "<h2>Customer account successfully created.</h2>";
                                $action = "Created customer account";
                                create_log($link,$_SESSION['user_id'],$action);
                              }
                            }
                          }
                        }
                      }
                      else {
                        echo "<h2>Error creating customer account.</h2>";
                      }
                    }
                    else {
                      echo "<h2>Error preparing statement.</h2>";
                    }
                  }
                }

                //
                // Update admin
                //
                if(isset($_POST['update_admin'])) {
                  ob_end_clean();
                  ob_start();
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  echo "<div class='well'>";
                  echo "<h1>Update Administrator:</h1>";
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  $query = "SELECT user.user_id, user.fname, user.lname FROM admin JOIN user ON admin.admin_id = user.user_id";

                  if($stmt = mysqli_prepare($link, $query)) {
                    mysqli_stmt_bind_result($stmt, $col1, $col2, $col3);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    echo "<table class='table table-striped'><thead>";
                    echo "<th>Administrator ID</th>";
                    echo "<th>First Name</th>";
                    echo "<th>Last Name</th>";
                    while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                      echo "<tr>";
                      $admin_id = $row[0];
                      foreach ($row as $r) {
                        echo "<td>$r</td>";
                      }
                      echo '<td><form action="administrator.php" method="POST"><button type="submit" class="btn btn-warning" name="load_admin" value = "load_admin">Edit</button><input type="hidden" name="admin_id_to_edit" value="'.$admin_id.'"></form></td>';
                      echo '<td><form action="administrator.php" method="POST"><button type="submit" class="btn btn-danger" name="delete_admin" value = "delete_admin">Delete</button><input type="hidden" name="admin_id_to_delete" value="'.$admin_id.'"></form></td>';
                      echo "</tr>";
                    }
                    echo "</table>";
                    echo "</form>";
                  }
                  echo "</form>";
                  echo "</div>";
                }
                if(isset($_POST['load_admin'])) {
                  if(empty($_POST['admin_id_to_edit'])) {
                    echo "<h2>Please enter an employee number</h2>";
                  }
                  else {
                    $edit_id = $_POST['admin_id_to_edit'];
                    $query = "SELECT * FROM user WHERE user.user_id = '$edit_id'";
                    if($stmt = mysqli_prepare($link, $query)) {
                      mysqli_stmt_bind_result($stmt, $col1, $col2, $col3, $col4);
                      mysqli_stmt_execute($stmt);
                      $result = mysqli_stmt_get_result($stmt);
                      while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                        $edit_id = $row[0];
                        $fname = $row[1];
                        $lname = $row[2];
                        $role = $row[3];
                      }
                      $query = "SELECT passname, password FROM authentication WHERE user_id = '$edit_id'";
                      $result = mysqli_query($link, $query);
                      if($result) {
                        $row = mysqli_fetch_array($result, MYSQLI_NUM);
                        $user = $row[0];
                        $pass = $row[1];
                      }
                      if(strcmp($role, 'admin') == 0) {
                        ob_end_clean();
                        ob_start();
                        echo "<div class='well'>";
                        echo "<h1>Update Administrator:</h1>";
                        echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                        echo "<br>
                        <br><label>Administrator ID:</label>
                        <input type='number' name='user_id' value='".$edit_id."' class='form-control' readonly>
                        <br><label>Administrator First Name:</label>
                        <input type='text' name='new_fname' value='".$fname."' class='form-control'>
                        <br><label>Administrator Last Name:</label>
                        <input type='text' name='new_lname' value='".$lname."' class='form-control'>
                        <br><label>Administrator Last Name:</label>
                        <input type='text' name='new_user' value='".$user."' class='form-control'>
                        <br><label>Administrator Last Name:</label>
                        <input type='text' name='new_pass' value='".$pass."' class='form-control'>
                        <br><button type='submit' name='edit_admin' value='edit_admin' class='btn btn-primary'>Update Administrator</button>
                        </form>
                        ";
                      }
                      else {
                        echo "<h2>The employee ID is not an administrator</h2>";
                      }
                    }
                    else {
                      echo "<h2>Error preparing statment.</h2>";
                    }
                  }
                }
                if(isset($_POST['edit_admin'])) {
                  if(empty($_POST['new_fname']) || empty($_POST['new_lname']) || empty($_POST['new_pass']) || empty($_POST['new_user'])) {
                    echo "<h2>Please fill out all fields.</h2>";
                  }
                  else {
                    $sql = "UPDATE user SET fname=?, lname=? WHERE user_id = ?";
                    if($stmt = mysqli_prepare($link, $sql)) {
                      mysqli_stmt_bind_param($stmt, 'ssi', $_POST['new_fname'], $_POST['new_lname'], $_POST['user_id']);
                      if(mysqli_stmt_execute($stmt)) {
                        $sql = "UPDATE authentication SET passname=?, password=? WHERE user_id=?";
                        if($stmt = mysqli_prepare($link, $sql)) {
                          mysqli_stmt_bind_param($stmt, 'ssi', $_POST['new_user'], md5($_POST['new_pass']), $_POST['user_id']);
                          if(mysqli_stmt_execute($stmt)) {
                            echo "<h2>Administrator account has been updated.</h2>";
                            $action = "Updated administrator account";
                            create_log($link,$_SESSION['user_id'],$action);
                          }
                          else {
                            echo "<h2>Error updating administrator account.</h2>";
                          }
                        }
                        else {
                          echo "<h2>Error preparing statment.</h2>";
                        }
                      }
                      else {
                        echo "<h2>Error updating administrator account.</h2>";
                      }
                    }
                    else {
                      echo "<h2>Error preparing statment.</h2>";
                    }
                  }
                }
                if(isset($_POST['delete_admin'])) {
                  $delete_id = $_POST['admin_id_to_delete'];
                  $sql = "DELETE FROM admin WHERE admin_id = $delete_id";
                  if($stmt = mysqli_prepare($link, $sql)) {
                    if(mysqli_stmt_execute($stmt)) {
                      $sql = "DELETE FROM employee WHERE employee_id = $delete_id";
                      if($stmt = mysqli_prepare($link, $sql)) {
                        if(mysqli_stmt_execute($stmt)) {
                          $sql = "DELETE FROM user WHERE user_id = $delete_id";
                          if($stmt = mysqli_prepare($link, $sql)) {
                            if(mysqli_stmt_execute($stmt)) {
                              $sql = "DELETE FROM authentication WHERE user_id = $delete_id";
                              if($stmt = mysqli_prepare($link, $sql)) {
                                if(mysqli_stmt_execute($stmt)) {
                                  echo "<h2>Admin deleted</h2>";
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }

                //
                // Update attendant
                //
                if(isset($_POST['update_att'])) {
                  ob_end_clean();
                  ob_start();
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  echo "<div class='well'>";
                  echo "<h1>Update Attendant:</h1>";
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  $query = "SELECT user.user_id, user.fname, user.lname FROM attendant JOIN user ON attendant.attendant_id = user.user_id";

                  if($stmt = mysqli_prepare($link, $query)) {
                    mysqli_stmt_bind_result($stmt, $col1, $col2, $col3);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    echo "<table class='table table-striped'><thead>";
                    echo "<th>Attendant ID</th>";
                    echo "<th>First Name</th>";
                    echo "<th>Last Name</th>";
                    while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                      echo "<tr>";
                      $att_id = $row[0];
                      foreach ($row as $r) {
                        echo "<td>$r</td>";
                      }
                      echo '<td><form action="administrator.php" method="POST"><button type="submit" class="btn btn-warning" name="load_att" value = "load_att">Edit</button><input type="hidden" name="att_id_to_edit" value="'.$att_id.'"></form></td>';
                      echo '<td><form action="administrator.php" method="POST"><button type="submit" class="btn btn-danger" name="delete_att" value = "delete_att">Delete</button><input type="hidden" name="att_id_to_delete" value="'.$att_id.'"></form></td>';

                      echo "</tr>";
                    }
                    echo "</table>";
                    echo "</form>";
                  }
                }
                if(isset($_POST['load_att'])) {
                  $edit_id = $_POST['att_id_to_edit'];
                  $query = "SELECT * FROM user WHERE user.user_id = '$edit_id'";
                  if($stmt = mysqli_prepare($link, $query)) {
                    mysqli_stmt_bind_result($stmt, $col1, $col2, $col3, $col4);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                      $edit_id = $row[0];
                      $fname = $row[1];
                      $lname = $row[2];
                      $role = $row[3];
                    }
                    $query = "SELECT attendant_status, attendant_rank FROM attendant WHERE attendant_id = '$edit_id'";
                    $result = mysqli_query($link, $query);
                    if($result) {
                      $row = mysqli_fetch_array($result, MYSQLI_NUM);
                      $status = $row[0];
                      $rank = $row[1];
                    }
                    $query = "SELECT passname, password FROM authentication WHERE user_id = '$edit_id'";
                    $result = mysqli_query($link, $query);
                    if($result) {
                      $row = mysqli_fetch_array($result, MYSQLI_NUM);
                      $user = $row[0];
                      $pass = $row[1];
                    }
                    if(strcmp($role, 'attendant') == 0) {
                      ob_end_clean();
                      ob_start();
                      echo "<div class='well'>";
                      echo "<h1>Update Attendant Account:</h1>";
                      echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                      echo "<br>
                      <br><label>Attendant ID:</label>
                      <input type='number' name='user_id' value='".$edit_id."' class='form-control' readonly>
                      <br><label>Attendant First Name:</label>
                      <input type='text' name='new_fname' value='".$fname."' class='form-control'>
                      <br><label>Attendant Last Name:</label>
                      <input type='text' name='new_lname' value='".$lname."' class='form-control'>
                      <br><label>Attendant Status:</label>
                      <select name='new_status'class='form-control'>
                      <option value='active'>Active</option>
                      <option value='inactive'>Inactive</option>
                      </select>
                      <br><label>Attendant Rank:</label>
                      <select name='new_rank'class='form-control'>
                      <option value='junior'>Junior</option>
                      <option value='senior'>Senior</option>
                      </select>
                      <br><label>Attendant Username:</label>
                      <input type='text' name='new_user' value='".$user."' class='form-control'>
                      <br><label>Attendant Password:</label>
                      <input type='text' name='new_pass' value='".$pass."' class='form-control'>
                      <br><button type='submit' name='edit_att' value='edit_att' class='btn btn-primary'>Update Attendant</button>
                      </form>
                      ";
                    }
                    else {
                      echo "<h2>The employee ID is not an administrator</h2>";
                    }
                  }
                  else {
                    echo "<h2>Error preparing statment.</h2>";
                  }

                }
                if(isset($_POST['edit_att'])) {
                  if(empty($_POST['new_fname']) || empty($_POST['new_lname']) || empty($_POST['new_status']) || empty($_POST['new_rank']) || empty($_POST['new_pass']) || empty($_POST['new_user'])) {
                    echo "<h2>Please fill out all fields.</h2>";
                  }
                  else {
                    $sql = "UPDATE user SET fname=?, lname=? WHERE user_id = ?";
                    if($stmt = mysqli_prepare($link, $sql)) {
                      mysqli_stmt_bind_param($stmt, 'ssi', $_POST['new_fname'], $_POST['new_lname'], $_POST['user_id']);
                      if(mysqli_stmt_execute($stmt)) {
                        $sql = "UPDATE attendant SET attendant_status=?, attendant_rank=? WHERE attendant_id = ?";
                        if($stmt = mysqli_prepare($link, $sql)) {
                          mysqli_stmt_bind_param($stmt, 'ssi', $_POST['new_status'], $_POST['new_rank'], $_POST['user_id']);
                          if(mysqli_stmt_execute($stmt)) {
                            $sql = "UPDATE authentication SET passname=?, password=? WHERE user_id=?";
                            if($stmt = mysqli_prepare($link, $sql)) {
                              mysqli_stmt_bind_param($stmt, 'ssi', $_POST['new_user'], md5($_POST['new_pass']), $_POST['user_id']);
                              if(mysqli_stmt_execute($stmt)) {
                                echo "<h2>Attendant account has been updated.</h2>";
                                $action = "Updated attendant account";
                                create_log($link,$_SESSION['user_id'],$action);
                              }
                              else {
                                echo "<h2>Error updating attendant account.</h2>";
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
                if(isset($_POST['delete_att'])) {
                  $delete_id = $_POST['att_id_to_delete'];
                  $sql = "DELETE FROM attendant WHERE attendant_id = $delete_id";
                  if($stmt = mysqli_prepare($link, $sql)) {
                    if(mysqli_stmt_execute($stmt)) {
                      $sql = "DELETE FROM employee WHERE employee_id = $delete_id";
                      if($stmt = mysqli_prepare($link, $sql)) {
                        if(mysqli_stmt_execute($stmt)) {
                          $sql = "DELETE FROM user WHERE user_id = $delete_id";
                          if($stmt = mysqli_prepare($link, $sql)) {
                            if(mysqli_stmt_execute($stmt)) {
                              $sql = "DELETE FROM authentication WHERE user_id = $delete_id";
                              if($stmt = mysqli_prepare($link, $sql)) {
                                if(mysqli_stmt_execute($stmt)) {
                                  echo "<h2>Attendant deleted</h2>";
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }

                //
                // Update pilot
                //
                if(isset($_POST['update_pilot'])) {
                  ob_end_clean();
                  ob_start();
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  echo "<div class='well'>";
                  echo "<h1>Update Attendant:</h1>";
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  $query = "SELECT user.user_id, user.fname, user.lname FROM pilot JOIN user ON pilot.pilot_id = user.user_id";

                  if($stmt = mysqli_prepare($link, $query)) {
                    mysqli_stmt_bind_result($stmt, $col1, $col2, $col3);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    echo "<table class='table table-striped'><thead>";
                    echo "<th>Pilot ID</th>";
                    echo "<th>First Name</th>";
                    echo "<th>Last Name</th>";
                    while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                      echo "<tr>";
                      $pilot_id = $row[0];
                      foreach ($row as $r) {
                        echo "<td>$r</td>";
                      }
                      echo '<td><form action="administrator.php" method="POST"><button type="submit" class="btn btn-warning" name="load_pilot" value = "load_pilot">Edit</button><input type="hidden" name="pilot_id_to_edit" value="'.$pilot_id.'"></form></td>';
                      echo '<td><form action="administrator.php" method="POST"><button type="submit" class="btn btn-danger" name="delete_pilot" value = "delete_pilot">Delete</button><input type="hidden" name="pilot_id_to_delete" value="'.$pilot_id.'"></form></td>';
                      echo "</tr>";
                    }
                    echo "</table>";
                    echo "</form>";
                  }
                  echo "</form>";
                  echo "</div>";
                }
                if(isset($_POST['load_pilot'])) {
                  if(empty($_POST['pilot_id_to_edit'])) {
                    echo "<h2>Please enter an employee number</h2>";
                  }
                  else {
                    $edit_id = $_POST['pilot_id_to_edit'];
                    $query = "SELECT * FROM user WHERE user.user_id = '$edit_id'";
                    if($stmt = mysqli_prepare($link, $query)) {
                      mysqli_stmt_bind_result($stmt, $col1, $col2, $col3, $col4);
                      mysqli_stmt_execute($stmt);
                      $result = mysqli_stmt_get_result($stmt);
                      while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                        $edit_id = $row[0];
                        $fname = $row[1];
                        $lname = $row[2];
                        $role = $row[3];
                      }
                      $query = "SELECT status, flight_hours, pilot_rank FROM pilot WHERE pilot_id = '$edit_id'";
                      $result = mysqli_query($link, $query);
                      if($result) {
                        $row = mysqli_fetch_array($result, MYSQLI_NUM);
                        $status = $row[0];
                        $hours = $row[1];
                        $rank = $row[2];
                      }
                      $query = "SELECT passname, password FROM authentication WHERE user_id = '$edit_id'";
                      $result = mysqli_query($link, $query);
                      if($result) {
                        $row = mysqli_fetch_array($result, MYSQLI_NUM);
                        $user = $row[0];
                        $pass = $row[1];
                      }
                      if(strcmp($role, 'pilot') == 0) {
                        ob_end_clean();
                        ob_start();
                        echo "<div class='well'>";
                        echo "<h1>Update Pilot Account:</h1>";
                        echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                        echo "<br>
                        <br><label>Pilot ID:</label>
                        <input type='number' name='user_id' value='".$edit_id."' class='form-control' readonly>
                        <br><label>Pilot First Name:</label>
                        <input type='text' name='new_fname' value='".$fname."' class='form-control'>
                        <br><label>Pilot Last Name:</label>
                        <input type='text' name='new_lname' value='".$lname."' class='form-control'>
                        <br><label>Pilot Flight Hours:</label>
                        <input type='text' name='new_hours' value='".$hours."' class='form-control'>
                        <br><label>Pilot Status:</label>
                        <select name='new_status'class='form-control'>
                        <option value='active'>Active</option>
                        <option value='inactive'>Inactive</option>
                        </select>
                        <br><label>Pilot Rank:</label>
                        <select name='new_rank'class='form-control'>
                        <option value='first officer'>First Officier</option>
                        <option value='captain'>Captain</option>
                        <option value='senior captain'>Senior Captain</option>
                        </select>
                        <br><label>Pilot Username:</label>
                        <input type='text' name='new_user' value='".$user."' class='form-control'>
                        <br><label>Pilot Password:</label>
                        <input type='text' name='new_pass' value='".$pass."' class='form-control'>
                        <br><button type='submit' name='edit_pilot' value='edit_pilot' class='btn btn-primary'>Update Pilot</button>
                        </form>
                        ";
                      }
                      else {
                        echo "<h2>The employee ID is not a pilot</h2>";
                      }
                    }
                    else {
                      echo "<h2>Error preparing statment.</h2>";
                    }
                  }
                }
                if(isset($_POST['edit_pilot'])) {
                  if(empty($_POST['new_fname']) || empty($_POST['new_lname']) || empty($_POST['new_hours']) || empty($_POST['new_status']) || empty($_POST['new_rank']) || empty($_POST['new_pass']) || empty($_POST['new_user'])) {
                    echo "<h2>Please fill out all fields.</h2>";
                  }
                  else {
                    $sql = "UPDATE user SET fname=?, lname=? WHERE user_id = ?";
                    if($stmt = mysqli_prepare($link, $sql)) {
                      mysqli_stmt_bind_param($stmt, 'ssi', $_POST['new_fname'], $_POST['new_lname'], $_POST['user_id']);
                      if(mysqli_stmt_execute($stmt)) {
                        $sql = "UPDATE pilot SET status=?, pilot_rank=?, flight_hours=? WHERE pilot_id = ?";
                        if($stmt = mysqli_prepare($link, $sql)) {
                          mysqli_stmt_bind_param($stmt, 'ssii', $_POST['new_status'], $_POST['new_rank'], $_POST['new_hours'], $_POST['user_id']);
                          if(mysqli_stmt_execute($stmt)) {
                            $sql = "UPDATE authentication SET passname=?, password=? WHERE user_id=?";
                            if($stmt = mysqli_prepare($link, $sql)) {
                              mysqli_stmt_bind_param($stmt, 'ssi', $_POST['new_user'], md5($_POST['new_pass']), $_POST['user_id']);
                              if(mysqli_stmt_execute($stmt)) {
                                echo "<h2>Pilot account has been updated.</h2>";
                                $action = "Updated pilot account";
                                create_log($link,$_SESSION['user_id'],$action);
                              }
                              else {
                                echo "<h2>Error updating pilot account.</h2>";
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
                if(isset($_POST['delete_pilot'])) {
                  $delete_id = $_POST['pilot_id_to_delete'];
                  $sql = "DELETE FROM pilot WHERE pilot_id = $delete_id";
                  if($stmt = mysqli_prepare($link, $sql)) {
                    if(mysqli_stmt_execute($stmt)) {
                      $sql = "DELETE FROM employee WHERE employee_id = $delete_id";
                      if($stmt = mysqli_prepare($link, $sql)) {
                        if(mysqli_stmt_execute($stmt)) {
                          $sql = "DELETE FROM user WHERE user_id = $delete_id";
                          if($stmt = mysqli_prepare($link, $sql)) {
                            if(mysqli_stmt_execute($stmt)) {
                              $sql = "DELETE FROM authentication WHERE user_id = $delete_id";
                              if($stmt = mysqli_prepare($link, $sql)) {
                                if(mysqli_stmt_execute($stmt)) {
                                  echo "<h2>Pilot deleted</h2>";
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }

                //
                // Update customer
                //
                if(isset($_POST['update_customer'])) {
                  ob_end_clean();
                  ob_start();
                  echo "<div class='well'>";
                  echo "<h1>Update Customer Account:</h1>";
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  $query = "SELECT user.user_id, user.fname, user.lname FROM customer JOIN user ON customer.customer_id = user.user_id";

                  if($stmt = mysqli_prepare($link, $query)) {
                    mysqli_stmt_bind_result($stmt, $col1, $col2, $col3);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    echo "<table class='table table-striped'><thead>";
                    echo "<th>Customer ID</th>";
                    echo "<th>First Name</th>";
                    echo "<th>Last Name</th>";
                    while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                      echo "<tr>";
                      $customer_id = $row[0];
                      foreach ($row as $r) {
                        echo "<td>$r</td>";
                      }
                      echo '<td><form action="administrator.php" method="POST"><button type="submit" class="btn btn-warning" name="load_customer" value = "load_customer">Edit</button><input type="hidden" name="customer_id_to_edit" value="'.$customer_id.'"></form></td>';
                      echo '<td><form action="administrator.php" method="POST"><button type="submit" class="btn btn-danger" name="delete_customer" value = "delete_customer">Delete</button><input type="hidden" name="customer_id_to_delete" value="'.$customer_id.'"></form></td>';
                      echo "</tr>";
                    }
                    echo "</table>";
                    echo "</form>";
                  }
                  echo "</form>";
                  echo "</div>";
                }
                if(isset($_POST['load_customer'])) {
                  if(empty($_POST['customer_id_to_edit'])) {
                    echo "<h2>Please enter a customer number</h2>";
                  }
                  else {
                    $edit_id = $_POST['customer_id_to_edit'];
                    $query = "SELECT * FROM user WHERE user.user_id = '$edit_id'";
                    if($stmt = mysqli_prepare($link, $query)) {
                      mysqli_stmt_bind_result($stmt, $col1, $col2, $col3, $col4);
                      mysqli_stmt_execute($stmt);
                      $result = mysqli_stmt_get_result($stmt);
                      while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                        $edit_id = $row[0];
                        $fname = $row[1];
                        $lname = $row[2];
                        $role = $row[3];
                      }
                      $query = "SELECT age FROM customer WHERE customer_id = '$edit_id'";
                      $result = mysqli_query($link, $query);
                      if($result) {
                        $row = mysqli_fetch_array($result, MYSQLI_NUM);
                        $age = $row[0];
                      }
                      $query = "SELECT passname, password FROM authentication WHERE user_id = '$edit_id'";
                      $result = mysqli_query($link, $query);
                      if($result) {
                        $row = mysqli_fetch_array($result, MYSQLI_NUM);
                        $user = $row[0];
                        $pass = $row[1];
                      }
                      if(strcmp($role, 'customer') == 0) {
                        ob_end_clean();
                        ob_start();
                        echo "<div class='well'>";
                        echo "<h1>Update Customer:</h1>";
                        echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                        echo "<br>
                        <br><label>Customer ID:</label>
                        <input type='number' name='user_id' value='".$edit_id."' class='form-control' readonly>
                        <br><label>Customer First Name:</label>
                        <input type='text' name='new_fname' value='".$fname."' class='form-control'>
                        <br><label>Customer Last Name:</label>
                        <input type='text' name='new_lname' value='".$lname."' class='form-control'>
                        <br><label>Customer Age:</label>
                        <input type='number' name='new_age' value='".$age."' class='form-control'>
                        <br><label>Customer Username:</label>
                        <input type='text' name='new_user' value='".$user."' class='form-control'>
                        <br><label>Customer Password:</label>
                        <input type='text' name='new_pass' value='".$pass."' class='form-control'>
                        <br><button type='submit' name='edit_cus' value='edit_cus' class='btn btn-primary'>Update Customer</button>
                        </form>
                        ";
                      }
                      else {
                        echo "<h2>The user ID is not a customer.</h2>";
                      }
                    }
                    else {
                      echo "<h2>Error preparing statment.</h2>";
                    }
                  }
                }
                if(isset($_POST['edit_cus'])) {
                  if(empty($_POST['new_fname']) || empty($_POST['new_lname']) || empty($_POST['new_age']) || empty($_POST['new_pass']) || empty($_POST['new_user'])) {
                    echo "<h2>Please fill out all fields.</h2>";
                  }
                  else {
                    $sql = "UPDATE user SET fname=?, lname=? WHERE user_id = ?";
                    if($stmt = mysqli_prepare($link, $sql)) {
                      mysqli_stmt_bind_param($stmt, 'ssi', $_POST['new_fname'], $_POST['new_lname'], $_POST['user_id']);
                      if(mysqli_stmt_execute($stmt)) {
                        $sql = "UPDATE customer SET age=? WHERE customer_id = ?";
                        if($stmt = mysqli_prepare($link, $sql)) {
                          mysqli_stmt_bind_param($stmt, 'ii', $_POST['new_age'], $_POST['user_id']);
                          if(mysqli_stmt_execute($stmt)) {
                            $sql = "UPDATE authentication SET passname=?, password=? WHERE user_id=?";
                            if($stmt = mysqli_prepare($link, $sql)) {
                              mysqli_stmt_bind_param($stmt, 'ssi', $_POST['new_user'], md5($_POST['new_pass']), $_POST['user_id']);
                              if(mysqli_stmt_execute($stmt)) {
                                echo "<h2>Customer account has been updated.</h2>";
                                $action = "Updated customer account";
                                create_log($link,$_SESSION['user_id'],$action);
                              }
                              else {
                                echo "<h2>Error updating customer account.</h2>";
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
                if(isset($_POST['delete_customer'])) {
                  $delete_id = $_POST['customer_id_to_delete'];
                  $sql = "DELETE FROM customer WHERE customer_id = $delete_id";
                  if($stmt = mysqli_prepare($link, $sql)) {
                    if(mysqli_stmt_execute($stmt)) {
                      $sql = "DELETE FROM user WHERE user_id = $delete_id";
                      if($stmt = mysqli_prepare($link, $sql)) {
                        if(mysqli_stmt_execute($stmt)) {
                          $sql = "DELETE FROM authentication WHERE user_id = $delete_id";
                          if($stmt = mysqli_prepare($link, $sql)) {
                            if(mysqli_stmt_execute($stmt)) {
                              echo "<h2>Customer deleted</h2>";
                            }
                          }
                        }
                      }
                    }
                  }
                }

                //
                // Add flight
                //
                if(isset($_POST['add_flight'])) {
                  ob_end_clean();
                  ob_start();
                  echo "<div class='well'>";
                  echo "<h1>Add Flight:</h1>";
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  echo "<br><label>Plane ID:</label><br>";
                  echo "<input type='text' name='pid' class='form-control'><br>";
                  echo "<br><label>Originating City:</label><br>";
                  echo "<input type='text' name='from' class='form-control'><br>";
                  echo "<br><label>Destination City:</label><br>";
                  echo "<input type='text' name='to' class='form-control'><br>";
                  echo "<br><label>Ticket Price:</label><br>";
                  echo "<input type='number' name='cost' class='form-control'><br>";
                  echo "<br><label>Flight Date:</label><br>";
                  echo "<input type='date' name='dep_date' class='form-control'><br><br>";
                  echo "<br><label>Flight Departure Time:</label><br>";
                  echo "<input type='text' name='dep_time' class='form-control'><br><br>";
                  echo "<br><label>Flight Duration:</label><br>";
                  echo "<input type='text' name='duration' class='form-control'><br><br>";
                  echo "<button type='submit' name='insert_flight' value='insert_flight' class='btn btn-primary'>Add Flight</button>";
                  echo "</form>";
                  echo "</div>";
                }
                if(isset($_POST['insert_flight'])) {
                  if(empty($_POST['pid']) || empty($_POST['from']) || empty($_POST['to']) || empty($_POST['dep_date']) || empty($_POST['dep_time']) || empty($_POST['duration'])) {
                    echo "<h2>Please fill out all fields.</h2>";
                  }
                  else {
                    $pid = $_POST['pid'];
                    $from = $_POST['from'];
                    $to = $_POST['to'];
                    $cost = $_POST['cost'];
                    $date = $_POST['dep_date'];
                    $time = $_POST['dep_time'];
                    $duration = $_POST['duration'];
                    $sql = "INSERT INTO flight (departing_city, destination_city, plane_id, base_price, departure_date, departure_time, trip_duration)
                    VALUES ('$from', '$to', '$pid', '$cost', '$date', '$time', '$duration')";
                    if($stmt = mysqli_prepare($link, $sql)) {
                      if(mysqli_stmt_execute($stmt)) {
                        mysqli_stmt_close($stmt);
                        echo "<h2>Flight added.</h2>";
                        $action = "Added flight";
                        create_log($link,$_SESSION['user_id'],$action);
                      }
                      else {
                        mysqli_stmt_close($stmt);
                        echo "<h2>Error adding flight.</h2>";
                      }
                    }
                    else {
                      echo "<h2>Error preparing statement.</h2>";
                    }
                  }
                }

                //
                // Update flight
                //
                if(isset($_POST['update_flight'])) {
                  ob_end_clean();
                  ob_start();
                  echo "<div class='well'>";
                  echo "<h1>Update Flight:</h1>";
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  $query = "SELECT * FROM flight";

                  if($stmt = mysqli_prepare($link, $query)) {
                    mysqli_stmt_bind_result($stmt, $col1, $col2, $col3, $col4, $col5, $col6, $col7, $col8);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    echo "<table class='table table-striped'><thead>";
                    echo "<th>Flight ID</th>";
                    echo "<th>Departing City</th>";
                    echo "<th>Destination City</th>";
                    echo "<th>Plane ID</th>";
                    echo "<th>Ticket Price</th>";
                    echo "<th>Days Departing</th>";
                    echo "<th>Departure Time</th>";
                    echo "<th>Flight Duration</th>";
                    while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                      echo "<tr>";
                      $flight_id = $row[0];
                      foreach ($row as $r) {
                        echo "<td>$r</td>";
                      }
                      echo '<td><form action="administrator.php" method="POST"><button type="submit" class="btn btn-warning" name="load_flight" value = "load_flight">Edit</button><input type="hidden" name="flight_id_to_edit" value="'.$flight_id.'"></form></td>';
                      echo '<td><form action="administrator.php" method="POST"><button type="submit" class="btn btn-danger" name="delete_flight" value = "delete_flight">Delete</button><input type="hidden" name="flight_id_to_delete" value="'.$flight_id.'"></form></td>';
                      echo "</tr>";
                    }
                    echo "</table>";
                  }
                  echo "</form>";
                  echo "</div>";
                }
                if(isset($_POST['load_flight'])) {
                  ob_end_clean();
                  ob_start();
                  $fid = $_POST['flight_id_to_edit'];
                  $sql = "SELECT * FROM flight WHERE flight_id = '$fid'";
                  if($stmt = mysqli_prepare($link, $sql)) {
                    mysqli_stmt_bind_result($stmt, $col1, $col2, $col3, $col4, $col5, $col6, $col7, $col8);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    echo "<div class='well'>";
                    echo "<h1>Update Flight:</h1>";
                    echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                    echo "<br><br>";
                    if($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                      $flight_id = $row[0];
                      $departing_city = $row[1];
                      $destination_city = $row[2];
                      $plane_id = $row[3];
                      $price = $row[4];
                      $date = $row[5];
                      $depature_time = $row[6];
                      $flight_duration = $row[7];
                      echo "
                      <form action='administrator.php' method='POST'>
                      <label>Flight ID:</label>
                      <br>
                      <input type='text' name='fid' value='".$flight_id."' class='form-control' readonly>
                      <br><br>
                      <label>Departing City:</label>
                      <br>
                      <input type='text' name='new_dep' value='".$departing_city."' class='form-control'>
                      <br><br>
                      <label>Destination City:</label>
                      <br>
                      <input type='text' name='new_dest' value='".$destination_city."' class='form-control'>
                      <br><br>
                      <label>Plane ID:</label>
                      <br>
                      <input type='text' name='new_pid' value='".$plane_id."' class='form-control'>
                      <br><br>
                      <label>Cost:</label>
                      <br>
                      <input type='number' name='new_price' value='".$price."' class='form-control'>
                      <br><br>
                      <label>Departure Date:</label>
                      <br>
                      <input type='date' name='new_date' value='".$date."' class='form-control'>
                      <br><br>
                      <label>Departure Time:</label>
                      <br>
                      <input type='text' name='new_dep_time' value='".$depature_time."' class='form-control'>
                      <br><br>
                      <label>Flight Duration:</label>
                      <br>
                      <input type='text' name='new_duration' value='".$flight_duration."' class='form-control'>
                      <br>
                      <button type='submit' class='btn btn-primary' name='edit_flight' value ='edit_fligh'>Update Flight</button>
                      </form>
                      </div>";
                    }
                    else {
                      echo "<h2>The flight number you have entered does not exist.</h2>";
                    }
                  }
                }
                if(isset($_POST['edit_flight'])) {
                  $flight_id = $_POST['fid'];
                  $new_dep = $_POST['new_dep'];
                  $new_dest = $_POST['new_dest'];
                  $new_pid = $_POST['new_pid'];
                  $new_price = $_POST['new_price'];
                  $new_date = $_POST['new_date'];
                  $new_dep_time = $_POST['new_dep_time'];
                  $new_duration = $_POST['new_duration'];
                  $sql = "UPDATE flight SET plane_id = '$new_pid', departing_city = '$new_dep', destination_city = '$new_dest', base_price = '$new_price',
                  departure_date = '$new_date', trip_duration = '$new_duration', departure_time = '$new_dep_time' WHERE flight_id = '$flight_id'";
                  if($stmt = mysqli_prepare($link, $sql)) {
                    if(mysqli_stmt_execute($stmt)) {
                      mysqli_stmt_close($stmt);
                      echo "<h2>Flight successfully updated.</h2>";
                      $action = "Updated flight information";
                      create_log($link,$_SESSION['user_id'],$action);
                    }
                    else {
                      mysqli_stmt_close($stmt);
                      echo "<h2>Error updating flight.</h2>";
                    }
                  }
                  else {
                    echo "<h2>Error preparing statement.</h2>";
                  }
                }
                if(isset($_POST['delete_flight'])) {
                  $delete_id = $_POST['flight_id_to_delete'];
                  $sql = "DELETE FROM flight WHERE flight_id = $delete_id";
                  if($stmt = mysqli_prepare($link, $sql)) {
                    if(mysqli_stmt_execute($stmt)) {
                      echo "<h2>Flight has been deleted.</h2>";
                    }
                  }
                }

                //
                // Add pilot to flight
                //
                if(isset($_POST['add_pilot_flight'])) {
                  ob_end_clean();
                  ob_start();
                  echo "<div class='well'>";
                  echo "<h1>Add Pilot to Flight:</h1>";
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  echo "<br><label>Enter the Pilot ID you wish to assign:</label><br>";
                  echo "<input type='number' name='pilot_id' class='form-control'><br>";
                  echo "<br><label>Enter the Flight ID you wish to assign to:</label><br>";
                  echo "<input type='number' name='flight_id' class='form-control'><br>";
                  echo "<button type='submit' name='assign_pilot' value='assign_pilot' class='btn btn-primary'>Assign Pilot</button>";
                }
                if(isset($_POST['assign_pilot'])) {
                  $pilot_id = $_POST['pilot_id'];
                  $query = "SELECT role FROM user WHERE user_id = '$pilot_id'";
                  $result = mysqli_query($link, $query);
                  if($result) {
                    $row = mysqli_fetch_array($result, MYSQLI_NUM);
                    $role = $row[0];
                    if(strcmp($role, 'pilot') != 0) {
                      echo "<h2>The ID entered is not a pilot.</h2>";
                    }
                    else {
                      $sql = "INSERT INTO pilot_flight (pilot_id, flight_id) VALUES (?, ?)";
                      if($stmt = mysqli_prepare($link, $sql)) {
                        mysqli_stmt_bind_param($stmt, 'ii', $_POST['pilot_id'], $_POST['flight_id']);
                        if(mysqli_stmt_execute($stmt)) {
                          echo "<h2>Pilot added to flight.</h2>";
                          $action = "Pilot added to flight";
                          create_log($link,$_SESSION['user_id'],$action);
                        }
                        else {
                          echo "<h2>Pilot is already assigned to that flight.</h2>";
                        }
                      }
                      else {
                        echo "<h2>Error preparing statement.</h2>";
                      }
                    }
                  }
                }

                //
                // Add attendant to flight
                //
                if(isset($_POST['add_att_flight'])) {
                  ob_end_clean();
                  ob_start();
                  echo "<div class='well'>";
                  echo "<h1>Add Attendant to Flight:</h1>";
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  echo "<br><label>Enter the Attendant ID you wish to assign:</label><br>";
                  echo "<input type='number' name='att_id' class='form-control'><br>";
                  echo "<br><label>Enter the Flight ID you wish to assign to:</label><br>";
                  echo "<input type='number' name='flight_id' class='form-control'><br>";
                  echo "<button type='submit' name='assign_att' value='assign_att' class='btn btn-primary'>Assign Attendant</button>";
                }
                if(isset($_POST['assign_att'])) {
                  $att_id = $_POST['att_id'];
                  $query = "SELECT role FROM user WHERE user_id = '$att_id'";
                  $result = mysqli_query($link, $query);
                  if($result) {
                    $row = mysqli_fetch_array($result, MYSQLI_NUM);
                    $role = $row[0];
                    if(strcmp($role, 'attendant') != 0) {
                      echo "<h2>The ID entered is not an attendant.</h2>";
                    }
                    else {
                      $sql = "INSERT INTO attendant_flight (attendant_id, flight_id) VALUES (?, ?)";
                      if($stmt = mysqli_prepare($link, $sql)) {
                        mysqli_stmt_bind_param($stmt, 'ii', $_POST['att_id'], $_POST['flight_id']);
                        if(mysqli_stmt_execute($stmt)) {
                          echo "<h2>Attendant added to flight.</h2>";
                          $action = "Attendant added to flight";
                          create_log($link,$_SESSION['user_id'],$action);
                        }
                        else {
                          echo "<h2>Attendant is already assigned to that flight.</h2>";
                        }
                      }
                      else {
                        echo "<h2>Error preparing statement.</h2>";
                      }
                    }
                  }
                }

                //
                // Add equipment
                //
                if(isset($_POST['add_equipment'])) {
                  ob_end_clean();
                  ob_start();
                  echo "<div class='well'>";
                  echo "<h1>Add Equipment:</h1>";
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  echo "<br><label>Plane Model:</label><br>";
                  echo "<input type='text' name='pmod' class='form-control'><br><br>";
                  echo "<label>Plane ID:</label><br>";
                  echo "<input type='text' name='pid' class='form-control'><br><br>";
                  echo "<label>Required Pilots:</label><br>";
                  echo "<input type='number' name='num_pilots' class='form-control'><br><br>";
                  echo "<label>Required Attendants:</label><br>";
                  echo "<input type='number' name='num_att' class='form-control'><br><br>";
                  echo "<label>Maximum Passengers:</label><br>";
                  echo "<input type='number' name='num_pass' class='form-control'><br><br>";
                  echo "<button type='submit' name='insert_equipment' value='insert_equipment' class='btn btn-primary'>Add Equipment</button>";
                  echo "</form>";
                  echo "</div>";
                }
                if(isset($_POST['insert_equipment'])) {
                  if(empty($_POST['pid']) || empty($_POST['pmod']) || empty($_POST['num_pilots']) || empty($_POST['num_att']) || empty($_POST['num_pass'])) {
                    echo "<h2>Please fill out all fields.</h2>";
                  }
                  else {
                    $model = $_POST['pmod'];
                    $sql = "INSERT IGNORE INTO model (plane_model, num_pilots, num_attendants, num_passengers) VALUES (?, ?, ?, ?)";
                    if($stmt = mysqli_prepare($link, $sql)) {
                      mysqli_stmt_bind_param($stmt, 'siii', $_POST['pmod'], $_POST['num_pilots'], $_POST['num_att'], $_POST['num_pass']);
                      if(mysqli_stmt_execute($stmt)) {
                        $sql = "INSERT INTO equipment (plane_id, plane_model) VALUES (?, ?)";
                        if($stmt = mysqli_prepare($link, $sql)) {
                          mysqli_stmt_bind_param($stmt, 'ss', $_POST['pid'], $_POST['pmod']);
                          if(mysqli_stmt_execute($stmt)) {
                            echo "<h2>Equipment has been successfully updated.</h2>";
                            $action = "Equipment added to inventory";
                            create_log($link,$_SESSION['user_id'],$action);
                          }
                        }
                      }
                      else {
                        echo "<h2>Error inserting equipment.</h2>";
                      }
                    }
                    else {
                      echo "<h2>Error preparing statement.</h2>";
                    }
                  }
                }


                //
                //  Remove Equipment
                //
                if(isset($_POST['update_equipment'])) {
                  ob_end_clean();
                  ob_start();
                  echo "<div class='well'>";
                  echo "<h1>Update Equipment:</h1>";
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  $query = "SELECT equipment.plane_id, equipment.plane_model, model.num_pilots, model.num_attendants, model.num_passengers FROM equipment LEFT JOIN model ON equipment.plane_model = model.plane_model";

                  if($stmt = mysqli_prepare($link, $query)) {
                    mysqli_stmt_bind_result($stmt, $col1, $col2, $col3, $col4, $col5);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    echo "<table class='table table-striped'><thead>";
                    echo "<th>Plane ID</th>";
                    echo "<th>Plane Model</th>";
                    echo "<th>Required Pilots</th>";
                    echo "<th>Required Attendants</th>";
                    echo "<th>Max Passengers</th>";
                    while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                      echo "<tr>";
                      $pid = $row[0];
                      foreach ($row as $r) {
                        echo "<td>$r</td>";
                      }
                      echo '<td><form action="administrator.php" method="POST"><button type="submit" class="btn btn-danger" name="delete_plane" value = "delete_plane">Delete</button><input type="hidden" name="pid" value="'.$pid.'"></form></td>';
                      echo "</tr>";
                    }
                    echo "</table>";
                    echo "</form>";
                    echo "</div>";
                  }
                }
                if(isset($_POST['delete_plane'])) {
                  $delete_id = $_POST['pid'];
                  $sql = "DELETE FROM equipment WHERE equipment.plane_id = '$delete_id'";
                  if (mysqli_query($link, $sql)) {
                    echo "<h2>Plane deleted successfully</h2>";
                    $action = "Equipment removed from inventory";
                    create_log($link,$_SESSION['user_id'],$action);
                  }
                  else {
                    echo "<h2>Error deleting plane.</h2>";
                  }
                }

                //
                // View logs
                //
                if(isset($_POST['view_logs'])) {
                  ob_end_clean();
                  ob_start();
                  echo "<div class='well'>";
                  echo "<h1>View Logs:</h1>";
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  echo "<br><label>Search by:</label><br>";
                  echo "<input type='radio' name='column' value='ip_address' checked='checked'> IP Address<br>";
                  echo "<input type='radio' name='column' value='action_date'> Date<br>";
                  echo "<input type='radio' name='column' value='action'> Action<br>";
                  echo "<input type='radio' name='column' value='user_id'> User ID<br>";
                  echo "<br><label>Search:</label><br>";
                  echo "<input type='text' name='search' class='form-control'><br><br>";
                  echo "<button type='submit' name='search_logs' value='search_logs' class='btn btn-primary'>Search Logs</button><br><br>";
                  echo "</form>";
                  echo "</div>";
                }
                if(isset($_POST['search_logs'])) {
                  $column = $_POST['column'];
                  $search = $_POST['search'];
                  $order = $_POST['order'];
                  $rows_shown = $_POST['rows_shown'];
                  ob_end_clean();
                  ob_start();
                  echo "<div class='well'>";
                  echo "<h1>View Logs:</h1>";
                  echo "<form role='form' action='administrator.php' method='POST' class='login-form'>";
                  echo "<br><label>Search by:</label><br>";
                  echo "<input type='radio' name='column' value='ip_address' checked='checked'> IP Address<br>";
                  echo "<input type='radio' name='column' value='action_date'> Date<br>";
                  echo "<input type='radio' name='column' value='action'> Action<br>";
                  echo "<input type='radio' name='column' value='user_id'> User ID<br>";
                  echo "<br><label>Search:</label><br>";
                  echo "<input type='text' name='search' class='form-control'><br><br>";
                  echo "<button type='submit' name='search_logs' value='search_logs' class='btn btn-primary'>Search Logs</button><br>";
                  $sql = "SELECT * FROM log WHERE $column LIKE '$search%'";
                  if($stmt = mysqli_prepare($link, $sql)) {
                    mysqli_stmt_bind_result($stmt, $col1, $col2, $col3, $col4, $col5);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    echo "<table class='table table-striped'><thead>";
                    echo "<th>Log ID</th>";
                    echo "<th>IP Address</th>";
                    echo "<th>Date/Time</th>";
                    echo "<th>Action</th>";
                    echo "<th>User ID</th>";
                    while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                      echo "<tr>";
                      foreach ($row as $r) {
                        echo "<td>$r</td>";
                      }
                      echo "</tr>";
                    }
                    echo "</table>";
                    echo "</form>";
                    echo "</div>";
                  }
                  else {
                    echo "<h2>Error preparing statement.</h2>";
                  }
                }
                ?>
              </div>
            </div>
          </div>
        </body>
        </html>
