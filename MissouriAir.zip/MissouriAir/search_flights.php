<?php
// Start the session
session_start();
?>

<?php require("includes/header.php"); ?>

  <!-- Top content -->
  <div class="top-content">
    <div class="inner-bg">
      <div class="container">
        <div class="row">
          <div class="col-sm-8 col-sm-offset-2 text">
            <h1><strong>Search</strong> Flights</h1>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-6 col-sm-offset-3 form-box">
            <div class="form-top">
              <div class="form-top-left">
                <h1 style="color:white"> Enter flight information: </h1>
              </div>
              <div class="form-top-right">
                <i class="fa fa-plane"></i>
              </div>
            </div>
            <div class="form-bottom">
              <form role="form" action ="search_flights.php" method="POST" class="">
                <div class="form-group row">
                  <div class="col-xs-6 col-xs-offset-3">
                    <h5>Flying from:</h5>
                    <input type="text" name="depart" placeholder="City or airport" class="form-control" id="">
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-xs-6 col-xs-offset-3">
                    <h5>Flying to:</h5>
                    <input type="text" name= "dest" placeholder="City or airport" class="form-control" id="">
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-xs-6 col-xs-offset-3">
                      <h5>Departing on:</h5>
                    <input type="date" name="date" class="form-control" id="">
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-xs-6 col-xs-offset-3">
                    <h5>Price range:</h5>
                    <select class="form-control" name="price">
                      <option value="1000"><$1000</option>
					  <option value="800"><$800</option>
					  <option value="600"><$600</option>
					  <option value="400"><$400</option>
					  <option value="200"><$200</option>
					  <option value="100"><$100</option>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
					  <div class="col-xs-6 col-xs-offset-3">
						<button type="submit" name='search' class="btn btn-success btn-sm">Search</button>
					  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php
	if(isset($_POST['search'])){
		$_SESSION['depart'] = $_POST['depart'];
		$_SESSION['dest'] = $_POST['dest'];
		$_SESSION['date'] = $_POST['date'];
		$_SESSION['price'] = $_POST['price'];
		$_SESSION['sortby'] = 'price';
		echo '<script type="text/javascript">
           window.location = "show_flights.php"
          </script>';
	}
?>

<?php require("includes/footer.php"); ?>