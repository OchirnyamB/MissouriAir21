<?php
// Start the session
session_start();
?>

<?php require("includes/header.php"); ?>

  <!-- Not great practice but static navbar is weird -->
  <br>
  <br>
  <br>

  <div class="container text-center">
    <div class="row">
      <div class="col-sm-3 well">
        <div class="well">
		  <form action = "search_flights.php">
			<button class="btn btn-primary">Go Back to Search</button><br><br>
          </form>
		  <form action = "index.php">
			<button class="btn btn-primary">Go to Home Page</button><br>
		  </form>
        </div>
        <div class="alert alert-success fade in">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
          <p><strong>Reminder!</strong></p>
          When you select a reservation later, you must enter first name, last  name, age and number of bags!
        </div>
      </div>
      <div class="col-sm-9">
        <div class="row">
          <div class="col-sm-12">
            <h1 class="flight-title">Flights Matching Your Search</h1>
          </div>
        </div>
        <!-- This is what will be printed in result loop -->
        <div class="row">
          <div class="col-sm-12">
            <div class="well">
              <?php
				   $depart = $_SESSION['depart']."%";	
                   $dest = $_SESSION['dest']."%";			
                   $price = $_SESSION['price'];
				   $date = $_SESSION['date'];
				   // Database connection
				   $hostname = 'localhost';
				   $username = 'CS3380GRP21';
				   $password = '5d91bc2';
				   $database = 'CS3380GRP21';
				   $conn = mysqli_connect($hostname, $username, $password, $database);
				   if (!$conn){
					  die("Failed to connect to MySQL:" .mysqli_connect_error());
				   }
				   else{
					  if(!$date){
						  date_default_timezone_set('America/Chicago');
						  $date = date('Y-m-d');
						  $sql = "SELECT * FROM flight 
									  WHERE departing_city LIKE ? 
									  AND destination_city LIKE ? 
									  AND departure_date >= ? 
									  AND base_price <= ? 
									  ORDER BY departing_city, destination_city, departure_date, departure_time, base_price";
					  }else{
						  $sql = "SELECT * FROM flight 
						  WHERE departing_city LIKE ? 
						  AND destination_city LIKE ? 
						  AND departure_date = ? 
						  AND base_price <= ? 
						  ORDER BY departing_city, destination_city, departure_date, departure_time, base_price";
					  }
					  if($stmt = mysqli_prepare($conn, $sql)){
						  mysqli_stmt_bind_param($stmt, "ssss", $depart, $dest, $date, $price);
						  mysqli_stmt_execute($stmt);
						  $result = mysqli_stmt_get_result($stmt);
						  $num_rows = $result->num_rows;
						  if($num_rows == 0){
							  echo "We're sorry no flights matching your criteria found!";
						  }
						  else{
							  while($row = mysqli_fetch_array($result, MYSQLI_NUM)){
								  $flight_key = $row[0];
								  $departure_city = $row[1];
								  $destination_city = $row[2];
								  $price = $row[4];
								  $date = $row[5];
								  $duration = $row[7];
								  echo "<div class='well'>";
								  echo "<p class='ideets'><b>$flight_key</b></p>";
								  echo "<p class='deets'><span class='glyphicon glyphicon-plane'></span><b>  Departure City:</b> $departure_city </p>";
								  echo "<p class='deets'><span class='glyphicon glyphicon-globe'></span><b>  Destination City:</b> $destination_city </p>";
								  echo "<p class='deets'><span class='glyphicon glyphicon-usd'></span><b>  Flight Price: </b>$price</p>";
								  echo "<p class='deets'><span class='glyphicon glyphicon-calendar'></span><b>  Flight Date: </b>$date </p>";
								  echo "<p class='deets'><span class='glyphicon glyphicon-time'></span> <b>  Duration: </b>$duration</p>";
								  echo "<form action='booking1.php' method = 'POST'>
								           <input type='hidden' name='flight_key' value='$flight_key'>
								           <input type='hidden' name='departure_city' value='$departure_city'>
										   <input type='hidden' name='destination_city' value='$destination_city'>
										   <input type='hidden' name='price' value='$price'>
										   <input type='hidden' name='date' value='$date'>
										   <button class='btn btn-primary'>Book this flight</button><br>
									    </form>";
								  echo "</div>";
							  }
							  // Free result
							  mysqli_free_result($result);
						  }
					  }else{
						  echo "prepare didn't work";
					  }
					   
				   }
              ?>
            </div>
          </div>
          <!-- This is what will be printed in result loop -->
        </div>
      </div>
    </div>
	
<?php require("includes/footer.php"); ?>
