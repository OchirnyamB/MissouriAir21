<?php
session_start();
include 'web_logging.php';
define("HOST", "LOCALHOST");
define("USERNAME", "CS3380GRP21");
define("PASSWORD", "5d91bc2");
define("DBNAME", "CS3380GRP21");

if(strcmp($_SESSION['role'], 'pilot') != 0) {
  header("location: access_denied.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pilot</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  /* Set black background color, white text and some padding */
  footer {
    background-color: #555;
    color: white;
    padding: 15px;
  }

  h3 {
    margin-top: 0;
  }

  #left-well {
    max-width: 200px;
  }

  .btn {
    width: 160px;
  }

  .content {
    margin-left: 5%;
    margin-right: 5%;
  }
  </style>
</head>
<body>

  <!-- navbar begin -->
  <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#">Missouri Airlines</a>
      </div>
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav">
          <li><a href="index.php">Home</a></li>
          <li><a href="search_flights.php">Search Flights</a></li>
          <li><a href="reservations.php">View Reservations</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <?php
            if(isset($_SESSION['user_id'])) {
              echo "<li><a href='account.php'>Account</a></li>";
              echo "<li><a href='logout.php'>Logout</a></li>";
            } else {
              echo "<li><a href='register.php'>Register</a></li>";
              echo "<li><a href='login.php'>Login</a></li>";
            }
          ?>
        </ul>
      </div><!--/.nav-collapse -->
    </div>
  </nav>
  <!-- navbar end -->

  <!-- Not great practice but static navbar is weird -->
  <br>
  <br>
  <br>

  <div class='content'>
    <h1> Welcome Pilot </h1>
    <h2> Employee Number: <?php echo $_SESSION['user_id'] ?> </h2>
    <div class="row">
      <div class="col-md-3">
        <div class="well" id="left-well">
          <h3>Actions:</h3>
          <form role="form" action="pilot.php" method="post">
            <button name='overview' value='overview' class='btn btn-success'>Overview </button><br><br>
            <button name='update_status' value='update_status' class='btn btn-success'>Update Status </button><br><br>
            <button name='update_rank' value="update_rank" class='btn btn-success'>Update Rank </button><br><br>
            <button name='update_hours' value='update_hours' class='btn btn-success'>Update Flight Hours </button><br><br>
            <button name='update_certs' value='update_certs' class='btn btn-success'>Update Certifications </button><br><br>
            <button name='view_flights' value='view_flights' class='btn btn-success'>View Flights </button><br><br>
            <button name='view_logs' value='view_logs' class='btn btn-success'>View Logs </button><br>
          </form>
        </div>
      </div>
      <div class="col-md-9">
        <?php
        $link = mysqli_connect(HOST, USERNAME, PASSWORD, DBNAME) or die ("103" . mysqli_connect_error);
        $id = $_SESSION['user_id'];

        // Prime the page
        $query = "SELECT fname, lname, pilot_rank, flight_hours, status FROM pilot JOIN user
        ON pilot.pilot_id = user.user_id WHERE user.user_id = '$id'";
        $result = mysqli_query($link,$query);
        if($result) {
          $row = mysqli_fetch_array($result, MYSQLI_NUM);
          ob_start();
          echo "<div class='well'>";
          echo "<h1>Pilot Inofrmation:</h1>";
          echo "<h2>First Name: " . $row[0] . "</h2>";
          echo "<h2>Last Name: " . $row[1] . "</h2>";
          echo "<h2>Rank: " . $row[2] . "</h2>";
          echo "<h2>Flight Hours: " . $row[3] . "</h2>";
          echo "<h2>Status: " . $row[4] . "</h2>";
          echo "</div>";
        }

        // Display Pilot Inofrmation
        if(isset($_POST['overview'])) {
          ob_end_clean();
          ob_start();
          $query = "SELECT fname, lname, pilot_rank, flight_hours, status FROM pilot JOIN user
          ON pilot.pilot_id = user.user_id WHERE user.user_id = '$id'";
          $result = mysqli_query($link,$query);
          if($result) {
            $row = mysqli_fetch_array($result, MYSQLI_NUM);
            echo "<div class='well'>";
            echo "<h1>Pilot Inofrmation:</h1>";
            echo "<h2>First Name: " . $row[0] . "</h2>";
            echo "<h2>Last Name: " . $row[1] . "</h2>";
            echo "<h2>Rank: " . $row[2] . "</h2>";
            echo "<h2>Flight Hours: " . $row[3] . "</h2>";
            echo "<h2>Status: " . $row[4] . "</h2>";
            echo "</div>";
          }
        }

        // Update Pilot Status
        if(isset($_POST['update_status'])) {
          ob_end_clean();
          ob_start();
          echo "<div class='well'>";
          echo "<h1>Update Pilot Status:</h1>";
          echo "<form role='form' action='pilot.php' method='post' class='login-form'>";
          echo "<br><label>Select your current status:</label><br>";
          echo "<select name='new_status' class='form-control'>";
          echo "<option value='active'>Active</option>";
          echo "<option value='inactive'>Inactive</option>";
          echo "</select><br><br>";
          echo "<button type='submit' name='set_status' value='set_status' class='btn btn-primary'>Update</button>";
          echo "</form>";
          echo "</div>";
        }
        if(isset($_POST['set_status'])) {
          $id = $_SESSION['user_id'];
          $status = $_POST['new_status'];
          $sql = "UPDATE pilot JOIN user ON pilot.pilot_id = user.user_id SET status='$status' WHERE user_id = '$id'";
          if($stmt = mysqli_prepare($link, $sql)) {
            if(mysqli_stmt_execute($stmt)) {
              mysqli_stmt_close($stmt);
              echo "<h2>Status successfully updated.</h2>";
              $action = "Updated pilot status";
              create_log($link,$_SESSION['user_id'],$action);
            }
            else {
              mysqli_stmt_close($stmt);
              echo "<h2>Error updating status.</h2>";
            }
          }
          else {
            echo "<h2>Error preparing statement.</h2>";
          }
        }



        if(isset($_POST['update_rank'])) {
          ob_end_clean();
          ob_start();
          echo "<div class='well'>";
          echo "<h1>Update Pilot Rank:</h1>";
          echo "<form role='form' action='pilot.php' method='post' class='login-form'>";
          echo "<br><label>Select your rank:</label><br>";
          echo "<select name='new_rank' class='form-control'>";
          echo "<option value='first officer'>First Officer</option>";
          echo "<option value='captain'>Captain</option>";
          echo "<option value='senior captain'>Senior Captain</option>";
          echo "</select><br><br>";
          echo "<button type='submit' name='set_rank' value='set_rank' class='btn btn-primary'>Update</button>";
          echo "</form>";
          echo "</div>";
        }
        if(isset($_POST['set_rank'])) {
          $id = $_SESSION['user_id'];
          $rank = $_POST['new_rank'];
          $sql = "UPDATE pilot JOIN user ON pilot.pilot_id = user.user_id SET pilot_rank='$rank' WHERE user_id = '$id'";
          if($stmt = mysqli_prepare($link, $sql)) {
            if(mysqli_stmt_execute($stmt)) {
              mysqli_stmt_close($stmt);
              echo "<h2>Rank successfully updated.</h2>";
              $action = "Updated pilot rank";
              create_log($link,$_SESSION['user_id'],$action);
            }
            else {
              mysqli_stmt_close($stmt);
              echo "<h2>Error updating rank.</h2>";
            }
          }
          else {
            echo "<h2>Error preparing statement.</h2>";
          }
        }



        if(isset($_POST['update_hours'])) {
          ob_end_clean();
          ob_start();
          echo "<div class='well'>";
          echo "<h1>Update Flight Hours:</h1>";
          echo "<form role='form' action='pilot.php' method='post' class='login-form'>";
          echo "<br><label>Enter your current number of flight hours:</label><br>";
          echo "<input type='text' name='new_hours' class='form-control'><br><br>";
          echo "<button type='submit' name='set_hours' value='set_hours' class='btn btn-primary'>Update</button>";
          echo "</form>";
          echo "</div>";
        }
        if(isset($_POST['set_hours'])) {
          $id = $_SESSION['user_id'];
          $hours = $_POST['new_hours'];
          $sql = "UPDATE pilot JOIN user ON pilot.pilot_id = user.user_id SET flight_hours='$hours' WHERE user_id = '$id'";
          if($stmt = mysqli_prepare($link, $sql)) {
            if(mysqli_stmt_execute($stmt)) {
              mysqli_stmt_close($stmt);
              echo "<h2>Flight hours successfully updated.</h2>";
              $action = "Updated pilot flight hours";
              create_log($link,$_SESSION['user_id'],$action);
            }
            else {
              mysqli_stmt_close($stmt);
              echo "<h2>Error updating flight hours.</h2>";
            }
          }
          else {
            echo "<h2>Error preparing statement.</h2>";
          }
        }



        if(isset($_POST['update_certs'])) {
          ob_end_clean();
          ob_start();
          echo "<div class='well'>";
          echo "<h1>Update Pilot Certifications:</h1>";
          echo "<form role='form' action='pilot.php' method='post' class='login-form'>";
          echo "<br><label>Select the model to add:</label><br>";
          $query2 = "SELECT DISTINCT plane_model FROM model";
          if($stmt = mysqli_prepare($link, $query2)) {
            mysqli_stmt_bind_result($stmt, $col1);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            echo "<select name='new_model' class='form-control'>";
            while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
              echo "<option ";
              echo "value='".$row[0]."'> ".$row[0];
              echo "</option>";
            }
            echo "</select><br><br>";
          }
          echo "<button type='submit' name='insert_model' value='insert_model' class='btn btn-primary'>Insert</button>";
          echo "<br><br>";
          $query = "SELECT pilot_model.plane_model FROM pilot JOIN pilot_model
          ON pilot.pilot_id = pilot_model.pilot_id WHERE pilot.pilot_id = '$id'";
          if($stmt = mysqli_prepare($link, $query)) {
            mysqli_stmt_bind_result($stmt, $col1);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            echo "<table class='table table-striped'><thead>";
            echo "<th>Plane Model</th>";
            while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
              echo "<tr>";
              $plane_model = $row[0]; // Store plane model
              foreach ($row as $r) {
                echo "<td>$r</td>";
              }
              echo '<td><form action="pilot.php" method="POST"><button type="submit" class="btn btn-danger" name="delete_plane" value = "delete_plane">Delete</button><input type="hidden" name="model" value="'.$plane_model.'"></form></td>';
              echo "</tr>";
            }
            echo "</table>";
          }
          echo "</form>";
          echo "</div>";
        }
        // Add a certification
        if(isset($_POST['insert_model'])) {
          $model = $_POST['new_model'];
          $sql = "INSERT INTO pilot_model (pilot_id, plane_model) VALUES ('$id', '$model')";
          if($stmt = mysqli_prepare($link, $sql)) {
            if(mysqli_stmt_execute($stmt)) {
              mysqli_stmt_close($stmt);
              echo "<h2>Certification added.</h2>";
              $action = "Added pilot certification";
              create_log($link,$_SESSION['user_id'],$action);
            }
            else {
              mysqli_stmt_close($stmt);
              echo "<h2>Error adding certification.</h2>";
            }
          }
          else {
            echo "<h2>Error preparing statement.</h2>";
          }
        }
        // Remove a certification
        if(isset($_POST['delete_plane'])) {
          $id = $_SESSION['user_id'];
          $model = $_POST['model'];
          $sql = "DELETE FROM pilot_model WHERE pilot_model.pilot_id = '$id' AND pilot_model.plane_model = '$model'";
          if($stmt = mysqli_prepare($link, $sql)) {
            if(mysqli_stmt_execute($stmt)) {
              mysqli_stmt_close($stmt);
              echo "<h2>Certification removed.</h2>";
              $action = "Removed pilot certification";
              create_log($link,$_SESSION['user_id'],$action);
            }
            else {
              mysqli_stmt_close($stmt);
              echo "<h2>Error removing certification.</h2>";
            }
          }
          else {
            echo "<h2>Error preparing statement.</h2>";
          }
        }

        // View all of the pilot's flights
        if(isset($_POST['view_flights'])) {
          $id = $_SESSION['user_id'];
          ob_end_clean();
          ob_start();
          echo "<div class='well'>";
          echo "<h1>View Pilot Flights:</h1>";
          echo "<form role='form' action='pilot.php' method='post' class='login-form'>";
          $query = "SELECT flight.flight_id, flight.plane_id, flight.departing_city, flight.destination_city, flight.departure_date, flight.departure_time, flight.trip_duration
                    FROM flight INNER JOIN pilot_flight ON flight.flight_id = pilot_flight.flight_id";
          if($stmt = mysqli_prepare($link, $query)) {
            mysqli_stmt_bind_result($stmt, $col1, $col2, $col3, $col4, $col5, $col6, $col7);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            echo "<table class='table table-striped'><thead>";
            echo "<th>Flight ID</th>";
            echo "<th>Plane ID</th>";
            echo "<th>Departing From</th>";
            echo "<th>Arriving In</th>";
            echo "<th>Departing On</th>";
            echo "<th>Departing At</th>";
            echo "<th>Flight Duration</th>";
            while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
              echo "<tr>";
              foreach ($row as $r) {
                echo "<td>$r</td>";
              }
              echo "</tr>";
            }
            echo "</table>";
          }
          echo "</form>";
          echo "</div>";
        }

        if(isset($_POST['view_logs'])) {
          ob_end_clean();
          ob_start();
          echo "<div class='well'>";
          echo "<h1>View Logs:</h1>";
          echo "<form role='form' action='pilot.php' method='POST' class='login-form'>";
          echo "<br><label>Search by:</label><br>";
          echo "<input type='radio' name='column' value='ip_address' checked='checked'> IP Address<br>";
          echo "<input type='radio' name='column' value='action_date'> Date<br>";
          echo "<input type='radio' name='column' value='action'> Action<br>";
          echo "<input type='radio' name='column' value='user_id'> User ID<br>";
          echo "<br><label>Search:</label><br>";
          echo "<input type='text' name='search' class='form-control'><br><br>";
          echo "<button type='submit' name='search_logs' value='search_logs' class='btn btn-primary'>Search Logs</button><br>";
          echo "</form>";
          echo "</div>";
        }
        if(isset($_POST['search_logs'])) {
          $column = $_POST['column'];
          $search = $_POST['search'];
          ob_end_clean();
          ob_start();
          echo "<div class='well'>";
          echo "<h1>View Logs:</h1>";
          echo "<form role='form' action='pilot.php' method='POST' class='login-form'>";
          echo "<br><label>Search by:</label><br>";
          echo "<input type='radio' name='column' value='ip_address' checked='checked'> IP Address<br>";
          echo "<input type='radio' name='column' value='action_date'> Date<br>";
          echo "<input type='radio' name='column' value='action'> Action<br>";
          echo "<br><label>Search:</label><br>";
          echo "<input type='text' name='search' class='form-control'><br><br>";
          echo "<button type='submit' name='search_logs' value='search_logs' class='btn btn-primary'>Search Logs</button><br><br>";
          $id = $_SESSION['user_id'];
          $sql = "SELECT * FROM log WHERE user_id = '$id' AND $column LIKE '$search%'";
          if($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_result($stmt, $col1, $col2, $col3, $col4, $col5);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            echo "<table class='table table-striped'><thead>";
            echo "<th>Log ID</th>";
            echo "<th>IP Address</th>";
            echo "<th>Date/Time</th>";
            echo "<th>Action</th>";
            echo "<th>User ID</th>";
            while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
              echo "<tr>";
              foreach ($row as $r) {
                echo "<td>$r</td>";
              }
              echo "</tr>";
            }
            echo "</table>";
            echo "</form>";
            echo "</div>";
          }
          else {
            echo "<h2>Error preparing statement.</h2>";
          }
        }
        ?>
      </div>
    </div>
  </div>

</body>
</html>
