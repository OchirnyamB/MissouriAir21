<?php
session_start();
require("includes/header.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <title>Booking</title>
 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 <script src="http://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
 <script src="http://maxcdn.bootstrapcdn.com/bootsstrap/3.3.7/js/bootsrap.min.js">
 </script>
 <style>

footer{
 background-color: #555;
 color: white;
 padding: 15px;
}

h1 {
   margin-top: 50px;
}

 #left-well{
 max-width: 200px;
}
 .btn {
  width: 160px;
 }
 </style>
</head>
<body>
<?php
   $departure_city = $_POST['departure_city'];
   $destination_city = $_POST['destination_city'];
   $price = $_POST['price'];
   $date = $_POST['date'];
   $flight_key = $_POST['flight_key'];
   
   $_SESSION['price'] = $price;
   $_SESSION['date'] = $date;
   $_SESSION['flight_key'] = $flight_key;
 
?>
<!-- Top content -->

  <div class="top-content">
    <div class="inner-bg">
      <div class="container">
        <div class="row">
          <div class="col-sm-6 col-sm-offset-3 form-box">
            <div class="form-top">
              <div class="form-top-left">
                <h1 style="color: #ffffff"> Booking Flight Summary: </h1>
              </div>
              <div class="form-top-right">
                <i class="fa fa-plane"></i>
              </div>
            </div>
            <div class="form-bottom">
              <form role="form" action ="booking_action.php" method="POST" class="">
                <div class="form-group row">
                  <div class="col-xs-6 col-xs-offset-3">
                    <label>Flying from:</label>
                    <input type="text" name="depart" value="<?php echo $departure_city ?>" class="form-control" id="" readonly>
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-xs-6 col-xs-offset-3">
                    <label>Flying to:</label>
                    <input type="text" name= "dest" value="<?php echo $destination_city ?>" class="form-control" id="" readonly> 
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-xs-6 col-xs-offset-3">
                      <label>Departing on:</label>
                    <input type="text" name="date" value="<?php echo $date ?>" class="form-control" id="" readonly>
                  </div>
                </div>
				<div class="form-group row">
                  <div class="col-xs-6 col-xs-offset-3">
                      <label>Price:</label>
                    <input type="text" name="date" value=<?php echo '$'.$price ?> class="form-control" id="" readonly>
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-xs-6 col-xs-offset-3">
                    <label>Please enter your number of bags:</label>
                    <select class="form-control" name="number_bags">
                      <option value="1">1</option>
					  <option value="2">2</option>
					  <option value="3">3</option>
					  <option value="4">4</option>
					  <option value="5">5</option>
					  <option value="6">6</option>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
					  <div class="col-xs-6 col-xs-offset-3">
						<button type="submit" name='book' class="btn btn-success btn-sm">Book</button>
						<a href="search_flights.php"><b>Cancel</b></a>
					  </div>	  
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php
require("includes/footer.php");
?>
                

