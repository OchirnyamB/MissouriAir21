<?php
  session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Missouri Airlines</title>

  <!-- Bootstrap core CSS -->
  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
  
  <!-- CSS -->
	<link href="https://fonts.googleapis.com/css?family=Hind:300,400,500,600,700|Ubuntu:300,400,500,500i,700" rel="stylesheet">
	<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">
	<link rel="stylesheet" href="assets/font-awesome/css/font-awesome.css">

  <!-- Favicons -->
	<link rel="apple-touch-icon" sizes="180x180" href="favicons/apple-touch-icon.png">
	<link rel="icon" type="image/png" href="favicons/favicon-32x32.png" sizes="32x32">
	<link rel="icon" type="image/png" href="favicons/favicon-16x16.png" sizes="16x16">
	<link rel="manifest" href="favicons/manifest.json">
	<link rel="mask-icon" href="favicons/safari-pinned-tab.svg" color="#5bbad5">
	<meta name="theme-color" content="#ffffff">
	
  <!-- My CSS -->
  <link rel="stylesheet" type="text/css" href="main.css">

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

</head>

<body onload="startLoop()">

  <!-- navbar begin -->
  <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#">Missouri Airlines</a>
      </div>
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav">
          <li><a href="index.php">Home</a></li>
          <li><a href="search_flights.php">Search Flights</a></li>
          <li><a href="reservations.php">View Reservations</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          
        <?php
              if(isset($_SESSION['user_id'])){
                echo"<li class='active'><a href='account.php'>Account</a></li>";
              }else{
                echo"<li class='active'><a href='register.php'>Register</a></li>";
              }
        ?>

          <li class="active"><a href="login.php"><?php if(isset($_SESSION['user_id'])){echo "Logout";}else{echo "Login";} ?></a></li>
        </ul>
      </div><!--/.nav-collapse -->
    </div>
  </nav>
  <!-- navbar end -->

  <div id="jmb" class="lead text-center jumbotron">
    <br>
    <br>
    <h1>Missouri Airlines</h1>
    <p>You'll feel lke you're floating on air.</p>
  </div>

  <div class="container">

    <div class="starter-template text-center">
      <h1>Missouri Airlines</h1>
      <p class="lead">Welcome to Missouri Airlines, The Luxury Airline of the Midwest.<br>
        From San Francisco to New York City, You'll feel lke you're floating on air.</p>
      </div>
      <br>
      <div class="row lead text-center">
        <div class="col-md-4">
          <form action="search_flights.php">
            <button type="submit" class="btn btn-secondary btn-lg">
              Search Flights
              <span class="glyphicon glyphicon-plane" aria-hidden="true"></span>
            </button>
          </form>
        </div>
        <div class="col-md-4">
          <form action="login.php">
            <button type="submit" class="btn btn-secondary btn-lg">
              User Login
              <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
          </form>
       </div> 
       <div class="col-md-4">
          <form action="register.php">
            <button type="submit" class="btn btn-secondary btn-lg">
              User Register
              <span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>
            </button>
          </form>
        </div>
      </div>

    </div><!-- /.container -->

    <script>
    i = 1;
    function setBackground(){
      i++;
      if(i == 6) { i = 1;}
      newImage = 'url("images/city' + i + '.jpg")';
      document.getElementById('jmb').style.backgroundImage = newImage;
    }

    var iFrequency = 5000; // expressed in miliseconds
    var myInterval = 0;

    // STARTS and Resets the loop if any
    function startLoop() {
      if(myInterval > 0) clearInterval(myInterval);  // stop
      myInterval = setInterval( "setBackground()", iFrequency );  // run
    }
    </script>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="bootstrap/assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
  </body>
  </html>
