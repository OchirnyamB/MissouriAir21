<?php
function create_log($link,$user_id,$action){
  $ip = $_SERVER['REMOTE_ADDR'];
  $sql = "INSERT INTO log (ip_address, action_date, action, user_id) VALUES ('$ip',CURRENT_TIMESTAMP,'$action','$user_id')";
  if($stmt = mysqli_prepare($link, $sql)) {
    mysqli_stmt_execute($stmt);
  }
  return;
}
?>
