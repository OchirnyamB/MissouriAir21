<?php
define("HOST", "LOCALHOST");
define("USERNAME", "CS3380GRP21");
define("PASSWORD", "5d91bc2");
define("DBNAME", "CS3380GRP21");
$link = mysqli_connect(HOST, USERNAME, PASSWORD, DBNAME);
if(isset($_POST['insert_admin'])) {
  if(empty($_POST['admin_fname']) || empty($_POST['admin_lname'])) {
    echo "Please enter a valid first and last name.";
  }
  else {
    $role = 'admin';
    $sql = "INSERT INTO admin (user.fname, user.lname, user.role, authentication.passname, authentication.password) VALUES (?, ?, ?, ?, ?)
    SELECT user.fname, user.lname, user.role, authentication.passname, authentication.password FROM user JOIN authentication
    ON user.user_id = authentication.user_id";
    if($stmt = mysqli_prepare($link, $sql)) {
      mysqli_stmt_bind_param($stmt, 'sssss', $_POST['admin_fname'], $_POST['admin_lname'], $_POST['admin_uname'], $_POST['admin_pass'], $role);
      if(mysqli_stmt_execute($stmt)) {
        echo "Administrator sucessfully added.";
      }
      else {
        echo "Error adding administrator";
      }
    }
    else {
      echo "Error preparing statement.";
    }
  }
}
?>
