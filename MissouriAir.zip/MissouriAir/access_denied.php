<?php
define("HOST", "LOCALHOST");
define("USERNAME", "CS3380GRP21");
define("PASSWORD", "5d91bc2");
define("DBNAME", "CS3380GRP21");

?>

<?php require("includes/header.php"); ?>

  <!-- Not great practice but static navbar is weird -->
  <br>
  <br>
  <br>
  <div class='content'>
    <h1 style = "font-weight:900; color:white"> Access Denied! </h1>
    <h3 style = "font-weight:500; color:white"> Your account does not have persmission to access this content. </h3>
  </div>
  
<?php require("includes/footer.php"); ?>