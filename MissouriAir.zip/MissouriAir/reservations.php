<?php
session_start();
require("includes/header.php");
?>
<br><br><br>
<div style="color: #ffffff; text-shadow: 0px 0px 70px #000000;">
		<?php 
		  $hostname = 'localhost';
		  $username = 'CS3380GRP21';
		  $password = '5d91bc2';
		  $database = 'CS3380GRP21';
		  $link = mysqli_connect($hostname, $username, $password, $database);
		  if (!$link){
			  die("Failed to connect to MySQL:" .mysqli_connect_error());
		  }else{
			      if(!isset($_SESSION['user_id'])){
						  echo '<script type="text/javascript">
						   window.location = "login.php"
						  </script>';
				  }else{
					  echo "<div class='col-sm-6 col-sm-offset-3'></div>";
					  echo "<div class='col-sm-6 col-sm-offset-3'>";
					  echo "<h1 style='color:#ffffff; text-shadow: 0px 0px 70px #000000;'>View Flight Reservations:</h1>";
					  echo "<form role='form' style='color:#ffffff; text-shadow: 0px 0px 70px #000000;' action='reservations.php' method='POST' class='login-form'>";
					  $id = $_SESSION['user_id'];
					  $query = "SELECT reservation.flight_id, flight.plane_id, flight.departing_city, flight.destination_city, reservation.date_reserved, reservation.num_bags, flight.base_price FROM reservation JOIN flight ON flight.flight_id = reservation.flight_id WHERE reservation.flight_id = flight.flight_id AND $id=reservation.customer_id";
					  if($stmt = mysqli_prepare($link, $query)) {
						mysqli_stmt_bind_result($stmt, $col1, $col2, $col3, $col4, $col5, $col6, $col7);
						mysqli_stmt_execute($stmt);
						$result = mysqli_stmt_get_result($stmt);
						if(mysqli_num_rows($result) == 0 ) {
						  echo "<h2>No reservations to show.</h2>";
						}
						echo "<table class='table table-striped'><thead>";
						echo "<th>Flight ID</th>";
						echo "<th>Plane ID</th>";
						echo "<th>Departing From</th>";
						echo "<th>Arriving In</th>";
						echo "<th>Departing On</th>";
						echo "<th>Number of Bags</th>";
						echo "<th>Ticket Price</th>";
						while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
						  echo "<tr>";
						  foreach ($row as $r) {
							echo "<td>$r</td>";
						  }
						  echo "</tr>";
						}
					  echo "</table>";
					  }
					  echo "</form>";
					  echo "</div>";
					  echo "<div class='col-sm-6 col-sm-offset-3'></div>";
				  }
			}
         ?>
 
</div>
<?php
require("includes/footer.php");
?>
