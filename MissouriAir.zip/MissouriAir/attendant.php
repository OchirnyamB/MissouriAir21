<?php
session_start();
include 'web_logging.php';
define("HOST", "LOCALHOST");
define("USERNAME", "CS3380GRP21");
define("PASSWORD", "5d91bc2");
define("DBNAME", "CS3380GRP21");
ob_start();

if(strcmp($_SESSION['role'], 'attendant') != 0) {
  header("location: access_denied.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Attendant</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  /* Set black background color, white text and some padding */
  footer {
    background-color: #555;
    color: white;
    padding: 15px;
  }

  h3 {
    margin-top: 0;
  }

  #left-well {
    max-width: 200px;
  }

  .btn {
    width: 160px;
  }

  .content {
    margin-left: 5%;
    margin-right: 5%;
  }
  </style>
</head>
<body>

  <!-- navbar begin -->
  <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#">Missouri Airlines</a>
      </div>
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav">
          <li><a href="index.php">Home</a></li>
          <li><a href="search_flights.php">Search Flights</a></li>
          <li><a href="reservations.php">View Reservations</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <?php
            if(isset($_SESSION['user_id'])) {
              echo "<li><a href='account.php'>Account</a></li>";
              echo "<li><a href='logout.php'>Logout</a></li>";
            } else {
              echo "<li><a href='register.php'>Register</a></li>";
              echo "<li><a href='login.php'>Login</a></li>";
            }
          ?>
        </ul>
      </div><!--/.nav-collapse -->
    </div>
  </nav>
  <!-- navbar end -->

  <!-- Not great practice but static navbar is weird -->
  <br>
  <br>
  <br>

  <div class='content'>
    <h1> Welcome Attendant </h1>
    <h2> Employee Number: <?php echo $_SESSION['user_id'] ?> </h2>
    <div class="row">
      <div class="col-md-3">
        <div class="well" id="left-well">
          <h3>Actions:</h3>
          <form role="form" action="attendant.php" method="POST">
            <button name="overview" value="overview" class="btn btn-success">Overview </button><br><br>
            <button name='update_status' value='update_status' class='btn btn-success'>Update Status </button><br><br>
            <button name='update_rank' value='update_rank' class='btn btn-success'>Update Rank </button><br><br>
            <button name="view_flights" value="view_flights" class="btn btn-success">View Flights </button><br><br>
            <button name="view_logs" value="view_logs" class="btn btn-success">View Logs </button><br>
          </form>
        </div>
      </div>
      <div class="col-md-9">

        <?php
        $link = mysqli_connect(HOST, USERNAME, PASSWORD, DBNAME) or die ("103" . mysqli_connect_error);
        $id = $_SESSION['user_id'];

        $query = "SELECT fname, lname, attendant_rank, attendant_status FROM attendant JOIN user
        ON attendant.attendant_id = user.user_id WHERE user.user_id = '$id'";

        $result = mysqli_query($link,$query);
        if($result) {
          $row = mysqli_fetch_array($result, MYSQLI_NUM);
          ob_start();
          echo "<div class='well'>";
          echo "<h1>Attendant Inofrmation:</h1>";
          echo "<h2>First Name: " . $row[0] . "</h2>";
          echo "<h2>Last Name: " . $row[1] . "</h2>";
          echo "<h2>Rank: " . $row[2] . "</h2>";
          echo "<h2>Status: " . $row[3] . "</h2>";
          echo "</div>";
        }


        if(isset($_POST['overview'])) {
          ob_end_clean();
          ob_start();
          $query = "SELECT fname, lname, attendant_rank, attendant_status FROM attendant JOIN user
                    ON attendant.attendant_id = user.user_id WHERE user.user_id = '$id'";
          $result = mysqli_query($link,$query);
          if($result) {
            $row = mysqli_fetch_array($result, MYSQLI_NUM);
            ob_start();
            echo "<div class='well'>";
            echo "<h1>Attendant Inofrmation:</h1>";
            echo "<h2>First Name: " . $row[0] . "</h2>";
            echo "<h2>Last Name: " . $row[1] . "</h2>";
            echo "<h2>Rank: " . $row[2] . "</h2>";
            echo "<h2>Status: " . $row[3] . "</h2>";
            echo "</div>";
          }
        }


        if(isset($_POST['update_status'])) {
          ob_end_clean();
          ob_start();
          echo "<div class='well'>";
          echo "<h1>Update Attendant Status:</h1>";
          echo "<form role='form' action='attendant.php' method='POST' class='login-form'>";
          echo "<br><br><select name='new_status' class='form-control'>";
          echo "<option value='active'>Active</option>";
          echo "<option value='inactive'>Inactive</option>";
          echo "</select><br><br>";
          echo "<button type='submit' name='set_status' value='set_status' class='btn btn-primary'>Update</button>";
          echo "</form>";
          echo "</div>";
        }
        if(isset($_POST['set_status'])) {
          $id = $_SESSION['user_id'];
          $status = $_POST['new_status'];
          $sql = "UPDATE attendant JOIN user ON attendant.attendant_id = user.user_id SET attendant_status='$status' WHERE user_id = '$id'";
          if($stmt = mysqli_prepare($link, $sql)) {
            if(mysqli_stmt_execute($stmt)) {
              mysqli_stmt_close($stmt);
              echo "Status successfully updated!";
              $action = "Updated attendant status";
              create_log($link,$_SESSION['user_id'],$action);

            }
            else {
              mysqli_stmt_close($stmt);
              echo "Error updating status.";
            }
          }
          else {
            echo "Error preparing statement.";
          }
        }


        if(isset($_POST['update_rank'])) {
          ob_end_clean();
          ob_start();
          echo "<div class='well'>";
          echo "<h1>Update Attendant Rank:</h1>";
          echo "<form role='form' action='attendant.php' method='POST' class='login-form'>";
          echo "<br><br><select name='new_rank' class='form-control'>";
          echo "<option value='junior'>Junior</option>";
          echo "<option value='senior'>Senior</option>";
          echo "</select><br><br>";
          echo "<button type='submit' name='set_rank' value='set_rank' class='btn btn-primary'>Update</button>";
          echo "</form>";
          echo "</div>";
        }
        if(isset($_POST['set_rank'])) {
          $id = $_SESSION['user_id'];
          $rank = $_POST['new_rank'];
          $sql = "UPDATE attendant JOIN user ON attendant.attendant_id = user.user_id SET attendant_rank='$rank' WHERE user_id = '$id'";
          if($stmt = mysqli_prepare($link, $sql)) {
            if(mysqli_stmt_execute($stmt)) {
              mysqli_stmt_close($stmt);
              echo "Rank successfully updated!";
              $action = "Updated attendant rank";
              create_log($link,$_SESSION['user_id'],$action);
            }
            else {
              mysqli_stmt_close($stmt);
              echo "Error updating rank.";
            }
          }
          else {
            echo "Error preparing statement.";
          }
        }


        if(isset($_POST['view_flights'])) {
          $id = $_SESSION['user_id'];
          ob_end_clean();
          ob_start();
          echo "<div class='well'>";
          echo "<h1>View Attendant Flights:</h1>";
          echo "<form role='form' action='attendant.php' method='POST' class='login-form'>";
          $query = "SELECT flight.flight_id, flight.plane_id, flight.departing_city, flight.destination_city, flight.departure_date, flight.departure_time, flight.trip_duration
                    FROM flight INNER JOIN attendant_flight ON flight.flight_id = attendant_flight.flight_id";
          if($stmt = mysqli_prepare($link, $query)) {
            mysqli_stmt_bind_result($stmt, $col1, $col2, $col3, $col4, $col5, $col6, $col7);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            echo "<table class='table table-striped'><thead>";
            echo "<th>Flight ID</th>";
            echo "<th>Plane ID</th>";
            echo "<th>Departing From</th>";
            echo "<th>Arriving In</th>";
            echo "<th>Departing On</th>";
            echo "<th>Departing At</th>";
            echo "<th>Flight Duration</th>";
            while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
              echo "<tr>";
              foreach ($row as $r) {
                echo "<td>$r</td>";
              }
              echo "</tr>";
            }
            echo "</table>";
            echo "</form>";
            echo "</div>";
          }
          else {
            echo "<h2>Error preparing statement.</h2>";
          }
        }

        if(isset($_POST['view_logs'])) {
          ob_end_clean();
          ob_start();
          echo "<div class='well'>";
          echo "<h1>View Logs:</h1>";
          echo "<form role='form' action='attendant.php' method='POST' class='login-form'>";
          echo "<br><label>Search by:</label><br>";
          echo "<input type='radio' name='column' value='ip_address' checked='checked'> IP Address<br>";
          echo "<input type='radio' name='column' value='action_date'> Date<br>";
          echo "<input type='radio' name='column' value='action'> Action<br>";
          echo "<input type='radio' name='column' value='user_id'> User ID<br>";
          echo "<br><label>Search:</label><br>";
          echo "<input type='text' name='search' class='form-control'><br><br>";
          echo "<button type='submit' name='search_logs' value='search_logs' class='btn btn-primary'>Search Logs</button><br><br>";
          echo "</form>";
          echo "</div>";
        }
        if(isset($_POST['search_logs'])) {
          $column = $_POST['column'];
          $search = $_POST['search'];
          $order = $_POST['order'];
          $rows_shown = $_POST['rows_shown'];
          ob_end_clean();
          ob_start();
          echo "<div class='well'>";
          echo "<h1>View Logs:</h1>";
          echo "<form role='form' action='attendant.php' method='POST' class='login-form'>";
          echo "<br><label>Search by:</label><br>";
          echo "<input type='radio' name='column' value='ip_address' checked='checked'> IP Address<br>";
          echo "<input type='radio' name='column' value='action_date'> Date<br>";
          echo "<input type='radio' name='column' value='action'> Action<br>";
          echo "<br><label>Search:</label><br>";
          echo "<input type='text' name='search' class='form-control'><br><br>";
          echo "<button type='submit' name='search_logs' value='search_logs' class='btn btn-primary'>Search Logs</button><br>";
          $sql = "SELECT * FROM log WHERE user_id = '$id' AND $column LIKE '$search%'";
          if($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_result($stmt, $col1, $col2, $col3, $col4, $col5);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            echo "<table class='table table-striped'><thead>";
            echo "<th>Log ID</th>";
            echo "<th>IP Address</th>";
            echo "<th>Date/Time</th>";
            echo "<th>Action</th>";
            echo "<th>User ID</th>";
            while($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
              echo "<tr>";
              foreach ($row as $r) {
                echo "<td>$r</td>";
              }
              echo "</tr>";
            }
            echo "</table>";
            echo "</form>";
            echo "</div>";
          }
          else {
            echo "<h2>Error preparing statement.</h2>";
          }
        }
        ?>

      </div>
    </div>
  </div>

</body>
</html>
